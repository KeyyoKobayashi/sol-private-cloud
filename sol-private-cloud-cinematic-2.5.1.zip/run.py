from dotenv import load_dotenv
load_dotenv()
import uvicorn
from app.config import settings

if __name__ == "__main__":
    uvicorn.run("app.main:app",host=settings.host,port=settings.port,reload=False,proxy_headers=settings.trust_proxy_headers,forwarded_allow_ips=settings.trusted_proxy if settings.trust_proxy_headers else "")
