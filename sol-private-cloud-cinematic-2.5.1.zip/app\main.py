from __future__ import annotations
import asyncio, json, logging, mimetypes, os, platform, shutil, socket, subprocess, sys, tempfile, threading, time, uuid, zipfile
from datetime import datetime, timezone, timedelta
from pathlib import Path, PurePosixPath
from typing import Any, Literal

from fastapi import FastAPI, Request, Response, HTTPException, Depends, WebSocket, WebSocketDisconnect, Query
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from starlette.background import BackgroundTask

from . import __version__, database as db, updater
from .config import settings, BASE_DIR
from .security import hash_password, verify_password, random_token, token_hash, iso_after, utcnow, sign_payload, verify_signed, validate_username, ROLE_DEFAULTS, ALL_PERMISSIONS
from .drive_manager import sync_detected, list_drives, get_drive, update_drive
from .filesystem import normalize_relative, validate_name, safe_path, list_folder, describe, ensure_policy, create_folder, rename, move_or_copy, trash_items, make_zip, directory_size, sniff_head
from .indexing import index_all, index_drive, search as index_search
from .advanced import unique_path,save_version,get_versions,get_version,version_file,restore_version,delete_version,thumbnail
from .events import hub
from .next_features import run_sync,run_due_syncs
from .intelligent import create_tag,list_tags,delete_tag,set_file_tags,file_tags,create_collection,list_collections,delete_collection,collection_items,index_content,content_search,scan_drive_intelligence,duplicate_groups,storage_intelligence,list_inbox,resolve_inbox,notifications,mark_notifications,list_rules,create_rule,delete_rule,run_rule,workspace_summary,process_arrival

STATIC=Path(__file__).parent/"static"
logging.basicConfig(level=logging.INFO,format='%(message)s')
logger=logging.getLogger("sol-cloud")
app=FastAPI(title="Sol Private Cloud API",version=__version__,docs_url="/api/docs" if settings.debug else None,redoc_url=None)
app.add_middleware(TrustedHostMiddleware,allowed_hosts=settings.allowed_hosts or ["*"])
if settings.cors_origins:app.add_middleware(CORSMiddleware,allow_origins=settings.cors_origins,allow_credentials=True,allow_methods=["GET","POST","PUT","PATCH","DELETE"],allow_headers=["Content-Type","X-CSRF-Token","X-File-Name","X-Upload-Offset"])
app.mount("/assets",StaticFiles(directory=STATIC),name="assets")

@app.middleware("http")
async def hardening(request:Request,call_next):
    started=time.perf_counter()
    try:response=await call_next(request)
    except Exception as exc:
        logger.exception(json.dumps({"event":"unhandled_error","path":request.url.path,"error":type(exc).__name__}))
        return JSONResponse({"error":{"code":"INTERNAL_ERROR","message":"Unexpected server error"}},500)
    response.headers.update({"X-Content-Type-Options":"nosniff","X-Frame-Options":"DENY","Referrer-Policy":"no-referrer","Permissions-Policy":"camera=(self), microphone=(), geolocation=()","Content-Security-Policy":"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; frame-src 'self' blob:; connect-src 'self' ws: wss:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'","Cache-Control":"no-store" if request.url.path.startswith('/api/') else "no-cache"})
    logger.info(json.dumps({"event":"request","method":request.method,"path":request.url.path,"status":response.status_code,"ms":round((time.perf_counter()-started)*1000,1)}))
    return response

def fail(status:int,code:str,message:str):raise HTTPException(status,{"code":code,"message":message})
def ip_of(request:Request)->str:
    direct=request.client.host if request.client else "unknown"
    trusted={x.strip() for x in settings.trusted_proxy.split(",") if x.strip()}
    if settings.trust_proxy_headers and direct in trusted:
        return request.headers.get("x-forwarded-for",direct).split(",")[0].strip()
    return direct

def session_token(request:Request)->str|None:return request.cookies.get("sol_session")
def current_user(request:Request)->dict:
    token=session_token(request)
    if not token:fail(401,"AUTH_REQUIRED","Sign in required")
    row=db.one("""SELECT u.*,s.csrf_hash,s.expires_at,s.id_hash FROM sessions s JOIN users u ON u.id=s.user_id
      WHERE s.id_hash=? AND s.expires_at>? AND u.enabled=1""",(token_hash(token),db.now_iso()))
    if not row:fail(401,"SESSION_EXPIRED","Session is invalid or expired")
    return dict(row)
def optional_user(request:Request)->dict|None:
    try:return current_user(request)
    except HTTPException:return None
def require_admin(user:dict=Depends(current_user))->dict:
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    return user
def csrf(request:Request,user:dict=Depends(current_user))->dict:
    provided=request.headers.get("x-csrf-token","")
    if not provided or token_hash(provided)!=user["csrf_hash"]:fail(403,"CSRF_REJECTED","Security token is missing or invalid")
    return user

def drive_permissions(user:dict,drive:dict,folder:str="")->set[str]:
    permissions=set(ROLE_DEFAULTS.get(user["role"],set()))
    if user["role"]!="ADMIN":
        rows=db.all("SELECT folder_path,rules FROM permissions WHERE user_id=? AND drive_id=?",(user["id"],drive["id"]))
        folder=normalize_relative(folder);best=None
        for row in rows:
            base=normalize_relative(row["folder_path"])
            if not base or folder==base or folder.startswith(base+"/"):
                if best is None or len(base)>len(best[0]):best=(base,json.loads(row["rules"]))
        if best:
            for p,enabled in best[1].items():
                if enabled:permissions.add(p)
                else:permissions.discard(p)
    if drive["read_only"]:permissions-={"UPLOAD","DELETE","RENAME","MOVE","COPY","CREATE_FOLDER"}
    flag={"UPLOAD":"allow_upload","DOWNLOAD":"allow_download","DELETE":"allow_delete","RENAME":"allow_rename","MOVE":"allow_move","COPY":"allow_copy","SHARE":"allow_share"}
    for permission,key in flag.items():
        if not drive[key]:permissions.discard(permission)
    return permissions
def access_drive(user:dict,drive_id:str,permission:str="VIEW",folder:str="")->dict:
    try:d=get_drive(drive_id)
    except FileNotFoundError:fail(404,"DRIVE_NOT_FOUND","Drive not found")
    except PermissionError as e:fail(403,"DRIVE_DISABLED",str(e))
    except OSError as e:fail(503,"DRIVE_OFFLINE",str(e))
    if permission not in drive_permissions(user,d,folder):fail(403,"PERMISSION_DENIED",f"{permission} permission is required")
    return d
def safe_call(action:str,user:dict,request:Request,drive_id:str,target:str,fn):
    try:
        value=fn();db.audit(action,target,"SUCCESS",user,drive_id,ip_of(request));return value
    except HTTPException:raise
    except FileNotFoundError as e:db.audit(action,target,"FAILED",user,drive_id,ip_of(request),str(e));fail(404,"NOT_FOUND",str(e))
    except FileExistsError as e:db.audit(action,target,"FAILED",user,drive_id,ip_of(request),str(e));fail(409,"ALREADY_EXISTS",str(e))
    except PermissionError as e:db.audit(action,target,"DENIED",user,drive_id,ip_of(request),str(e));fail(403,"FILESYSTEM_DENIED",str(e))
    except (ValueError,NotADirectoryError) as e:db.audit(action,target,"FAILED",user,drive_id,ip_of(request),str(e));fail(400,"INVALID_REQUEST",str(e))
    except OSError as e:db.audit(action,target,"FAILED",user,drive_id,ip_of(request),str(e));fail(507 if getattr(e,"errno",None)==28 else 500,"FILESYSTEM_ERROR",str(e))

def public_url(request:Request,path:str)->str:
    if settings.public_base_url:return settings.public_base_url+path
    return str(request.base_url).rstrip("/")+path

class SetupBody(BaseModel):username:str;password:str=Field(min_length=12,max_length=512);display_name:str=Field(min_length=1,max_length=80);cloud_name:str=Field(min_length=1,max_length=80)
class LoginBody(BaseModel):username:str;password:str
class SyncPairBody(BaseModel):name:str;local_path:str;drive_id:str;cloud_path:str="";enabled:bool=True;interval_seconds:int=Field(default=60,ge=15,le=86400)
class FileRequestBody(BaseModel):drive_id:str;target_path:str="";title:str;instructions:str="";expires_at:str|None=None;max_bytes:int|None=None;max_uploads:int|None=Field(None,ge=1);password:str|None=Field(None,min_length=12,max_length=256);allowed_extensions:list[str]=Field(default_factory=list)
class PublicRequestInit(BaseModel):name:str;size:int=Field(ge=0);password:str|None=None
class FolderBody(BaseModel):drive_id:str;path:str="";name:str
class RenameBody(BaseModel):drive_id:str;path:str;name:str
class TransferBody(BaseModel):source_drive_id:str;paths:list[str]=Field(min_length=1,max_length=100);destination_drive_id:str;destination_path:str=""
class DeleteBody(BaseModel):drive_id:str;paths:list[str]=Field(min_length=1,max_length=100)
class UploadInit(BaseModel):drive_id:str;path:str="";name:str;size:int=Field(ge=0);conflict_action:Literal["error","replace","keep_both","version"]="error"
class FavoriteBody(BaseModel):drive_id:str;path:str;favorite:bool=True
class ShareBody(BaseModel):drive_id:str;path:str;mode:Literal["VIEW","DOWNLOAD"]="DOWNLOAD";password:str|None=Field(None,min_length=12,max_length=256);expires_at:str|None=None;max_downloads:int|None=Field(None,ge=1)
class UserBody(BaseModel):username:str;display_name:str;password:str=Field(min_length=12,max_length=512);role:Literal["ADMIN","USER","READ_ONLY"]="USER";enabled:bool=True
class PasswordBody(BaseModel):password:str=Field(min_length=12,max_length=512)
class PermissionBody(BaseModel):user_id:int;drive_id:str;folder_path:str="";rules:dict[str,bool]
class TrashBody(BaseModel):ids:list[int]=Field(min_length=1,max_length=100)
class TagBody(BaseModel):name:str=Field(min_length=1,max_length=60);color:str='#d7ff45'
class FileTagsBody(BaseModel):drive_id:str;path:str;tag_ids:list[str]=Field(default_factory=list,max_length=50)
class CollectionBody(BaseModel):name:str=Field(min_length=1,max_length=100);criteria:dict[str,Any]=Field(default_factory=dict)
class InboxResolveBody(BaseModel):ids:list[str]=Field(default_factory=list,max_length=500);status:Literal['ORGANIZED','DISMISSED']='ORGANIZED'
class NotificationReadBody(BaseModel):ids:list[str]=Field(default_factory=list,max_length=500);all:bool=False
class IntelligenceScanBody(BaseModel):drive_id:str|None=None;max_files:int=Field(default=500,ge=1,le=5000);content:bool=True
class ContentIndexBody(BaseModel):drive_id:str;path:str
class RuleBody(BaseModel):name:str=Field(min_length=1,max_length=100);trigger:str='arrival';conditions:dict[str,Any]=Field(default_factory=dict);actions:list[dict[str,Any]]=Field(default_factory=list,max_length=20);enabled:bool=True;dry_run:bool=True
class RuleRunBody(BaseModel):drive_id:str;path:str;execute:bool=False
class UpdateSettingsBody(BaseModel):manifest_url:str=Field(default='',max_length=2048);automatic_checks:bool=True;check_hours:int=Field(default=24,ge=1,le=168)
class UpdateVersionBody(BaseModel):version:str=Field(min_length=5,max_length=50)
class UpdateInstallBody(BaseModel):version:str=Field(min_length=5,max_length=50);sha256:str=Field(min_length=64,max_length=64)

@app.on_event("startup")
def startup():
    db.init_db();sync_detected();logger.info(json.dumps({"event":"startup","version":__version__,"host":settings.host,"port":settings.port}))
    def worker():
        while True:
            try:sync_detected();index_all();cleanup_expired()
            except Exception:logger.exception(json.dumps({"event":"background_task_error"}))
            time.sleep(max(60,settings.index_interval_seconds))
    threading.Thread(target=worker,daemon=True,name="sol-indexer").start()
    def update_worker():
        time.sleep(10)
        while True:
            try:updater.automatic_check_due(__version__)
            except Exception:logger.exception(json.dumps({"event":"update_check_error"}))
            time.sleep(3600)
    threading.Thread(target=update_worker,daemon=True,name="sol-updater-check").start()
@app.on_event("shutdown")
def shutdown():logger.info(json.dumps({"event":"shutdown"}))
def cleanup_expired():
    db.execute("DELETE FROM sessions WHERE expires_at<?",(db.now_iso(),));db.execute("DELETE FROM upload_sessions WHERE expires_at<?",(db.now_iso(),));db.execute("DELETE FROM request_uploads WHERE created_at<?",((utcnow()-timedelta(days=1)).isoformat(),))
    cutoff=(utcnow()-timedelta(days=settings.trash_retention_days)).isoformat()
    for row in db.all("SELECT t.*,d.root_path FROM trash t JOIN drives d ON d.id=t.drive_id WHERE t.deleted_at<?",(cutoff,)):
        try:
            p=Path(row["root_path"])/".sol-trash"/row["trash_path"]
            shutil.rmtree(p,ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True)
            db.execute("DELETE FROM trash WHERE id=?",(row["id"],))
        except OSError:pass

@app.get("/api/setup/status")
def setup_status():return {"required":db.one("SELECT id FROM users LIMIT 1") is None,"app_name":db.setting_get("app_name",settings.app_name)}
@app.post("/api/setup")
def setup(body:SetupBody,request:Request,response:Response):
    if db.one("SELECT id FROM users LIMIT 1"):fail(409,"SETUP_COMPLETE","Initial setup is already complete")
    try:username=validate_username(body.username);password_hash=hash_password(body.password)
    except ValueError as e:fail(400,"INVALID_SETUP",str(e))
    uid=db.execute("INSERT INTO users(username,display_name,password_hash,role,enabled,created_at) VALUES(?,?,?,?,1,?)",(username,body.display_name.strip(),password_hash,"ADMIN",db.now_iso()))
    db.setting_set("app_name",body.cloud_name.strip());db.setting_set("appearance",{"primary":"#3478f6","theme":"system","animations":True,"default_view":"list","grid_size":"comfortable"})
    db.audit("SETUP","system","SUCCESS",{"id":uid,"username":username},ip=ip_of(request));return login(LoginBody(username=username,password=body.password),request,response)
@app.post("/api/auth/login")
def login(body:LoginBody,request:Request,response:Response):
    ip=ip_of(request);attempt=db.one("SELECT * FROM login_attempts WHERE ip=?",(ip,))
    if attempt:
        try:window_age=utcnow()-datetime.fromisoformat(attempt["window_start"])
        except (TypeError,ValueError):window_age=timedelta.max
        if window_age>timedelta(minutes=15):
            db.execute("DELETE FROM login_attempts WHERE ip=?",(ip,));attempt=None
    if attempt and attempt["blocked_until"] and attempt["blocked_until"]>db.now_iso():fail(429,"LOGIN_BLOCKED","Too many failed attempts; try again later")
    row=db.one("SELECT * FROM users WHERE username=? COLLATE NOCASE",(body.username.strip(),))
    if not row or not row["enabled"] or not verify_password(body.password,row["password_hash"]):
        failures=(attempt["failures"] if attempt else 0)+1;window=attempt["window_start"] if attempt else db.now_iso();blocked=(utcnow()+timedelta(minutes=15)).isoformat() if failures>=8 else None
        db.execute("INSERT INTO login_attempts(ip,failures,window_start,blocked_until) VALUES(?,?,?,?) ON CONFLICT(ip) DO UPDATE SET failures=excluded.failures,blocked_until=excluded.blocked_until",(ip,failures,window,blocked));db.audit("LOGIN",body.username,"FAILED",ip=ip,detail="Invalid credentials");fail(401,"INVALID_CREDENTIALS","Invalid username or password")
    db.execute("DELETE FROM login_attempts WHERE ip=?",(ip,));token=random_token(40);csrf_token=random_token(24);expires=iso_after(settings.session_hours)
    db.execute("INSERT INTO sessions(id_hash,user_id,csrf_hash,created_at,expires_at,ip,user_agent) VALUES(?,?,?,?,?,?,?)",(token_hash(token),row["id"],token_hash(csrf_token),db.now_iso(),expires,ip,request.headers.get("user-agent","")[:300]));db.execute("UPDATE users SET last_login=? WHERE id=?",(db.now_iso(),row["id"]));db.audit("LOGIN",row["username"],"SUCCESS",dict(row),ip=ip)
    response.set_cookie("sol_session",token,max_age=settings.session_hours*3600,httponly=True,secure=settings.cookie_secure,samesite="strict",path="/")
    response.set_cookie("sol_csrf",csrf_token,max_age=settings.session_hours*3600,httponly=False,secure=settings.cookie_secure,samesite="strict",path="/")
    return {"user":{"id":row["id"],"username":row["username"],"display_name":row["display_name"],"role":row["role"]},"csrf":csrf_token,"expires_at":expires}
@app.post("/api/auth/logout")
def logout(request:Request,response:Response,user:dict=Depends(csrf)):
    db.execute("DELETE FROM sessions WHERE id_hash=?",(token_hash(session_token(request) or ""),));response.delete_cookie("sol_session",path="/");response.delete_cookie("sol_csrf",path="/");db.audit("LOGOUT",user["username"],"SUCCESS",user,ip=ip_of(request));return {"ok":True}
@app.get("/api/auth/me")
def me(user:dict=Depends(current_user)):
    drives=[]
    for d in list_drives(True):
        if "VIEW" in drive_permissions(user,d):drives.append({k:d[k] for k in ("id","letter","display_name","icon","color","total_bytes","free_bytes","used_bytes","usage_percent","online","is_default")})
    return {"user":{"id":user["id"],"username":user["username"],"display_name":user["display_name"],"role":user["role"]},"drives":drives,"app_name":db.setting_get("app_name",settings.app_name),"appearance":db.setting_get("appearance",{}),"session_expires":user["expires_at"]}
@app.get("/api/auth/csrf")
def refresh_csrf_token(request:Request,response:Response,user:dict=Depends(current_user)):
    # Recover a missing/stale browser CSRF value without weakening mutation checks.
    # Same-origin JavaScript can read this response; cross-origin pages cannot.
    value=random_token(24);session_id=token_hash(session_token(request) or "")
    db.execute("UPDATE sessions SET csrf_hash=? WHERE id_hash=? AND user_id=?",(token_hash(value),session_id,user["id"]))
    response.set_cookie("sol_csrf",value,max_age=settings.session_hours*3600,httponly=False,secure=settings.cookie_secure,samesite="strict",path="/")
    return {"csrf":value,"expires_at":user["expires_at"]}

@app.get("/api/auth/sessions")
def sessions(user:dict=Depends(current_user)):
    return {"items":[dict(x) for x in db.all("SELECT created_at,expires_at,ip,user_agent FROM sessions WHERE user_id=? ORDER BY created_at DESC",(user["id"],))]}
@app.delete("/api/auth/sessions")
def revoke_sessions(request:Request,user:dict=Depends(csrf)):
    current=token_hash(session_token(request) or "");db.execute("DELETE FROM sessions WHERE user_id=? AND id_hash<>?",(user["id"],current));return {"ok":True}

@app.get("/api/drives")
def drives(user:dict=Depends(current_user)):
    items=[]
    for d in list_drives(False):
        if user["role"]=="ADMIN" or (d["enabled"] and "VIEW" in drive_permissions(user,d)):items.append(d)
    return {"items":items}
@app.post("/api/drives/refresh")
def refresh_drives(request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    items=sync_detected();db.audit("DRIVES_REFRESH","system","SUCCESS",user,ip=ip_of(request));return {"items":items}
@app.patch("/api/drives/{drive_id}")
async def patch_drive(drive_id:str,request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    data=await request.json()
    result=safe_call("DRIVE_UPDATE",user,request,drive_id,drive_id,lambda:update_drive(drive_id,data))
    if result["enabled"]:threading.Thread(target=lambda:index_drive(result),daemon=True).start()
    await hub.broadcast("drive.updated",{"drive_id":drive_id});return result
@app.post("/api/drives/{drive_id}/index")
def reindex_drive(drive_id:str,request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    drive=get_drive(drive_id);result=index_drive(drive);db.audit("DRIVE_INDEX",drive_id,"SUCCESS",user,drive_id,ip_of(request));return result

@app.get("/api/files")
def files(request:Request,drive_id:str,path:str="",sort_by:str="name",direction:str="asc",offset:int=0,limit:int=200,user:dict=Depends(current_user)):
    drive=access_drive(user,drive_id,"VIEW",path);result=safe_call("LIST",user,request,drive_id,path,lambda:list_folder(drive,path,sort_by,direction,offset,min(limit,500)))
    favs={x["relative_path"] for x in db.all("SELECT relative_path FROM favorites WHERE user_id=? AND drive_id=?",(user["id"],drive_id))}
    for item in result["items"]:item["favorite"]=item["path"] in favs
    result["permissions"]=sorted(drive_permissions(user,drive,path));result["drive"]={k:drive[k] for k in ("id","display_name","letter","color","read_only")};return result
@app.get("/api/files/info")
def file_info(drive_id:str,path:str,user:dict=Depends(current_user)):
    drive=access_drive(user,drive_id,"VIEW",path)
    try:rel,p=safe_path(drive,path,True);item=describe(drive,rel,p);item["permissions"]=sorted(drive_permissions(user,drive,str(PurePosixPath(rel).parent)));return item
    except Exception as e:fail(400,"FILE_INFO_FAILED",str(e))
@app.post("/api/files/create-folder")
async def folder(body:FolderBody,request:Request,user:dict=Depends(csrf)):
    drive=access_drive(user,body.drive_id,"CREATE_FOLDER",body.path);item=safe_call("CREATE_FOLDER",user,request,body.drive_id,body.path,lambda:create_folder(drive,body.path,body.name));threading.Thread(target=lambda:index_drive(drive),daemon=True).start();await hub.broadcast("files.changed",{"drive_id":body.drive_id,"path":body.path});return item
@app.post("/api/files/rename")
async def rename_api(body:RenameBody,request:Request,user:dict=Depends(csrf)):
    drive=access_drive(user,body.drive_id,"RENAME",body.path);item=safe_call("RENAME",user,request,body.drive_id,body.path,lambda:rename(drive,body.path,body.name));threading.Thread(target=lambda:index_drive(drive),daemon=True).start();await hub.broadcast("files.changed",{"drive_id":body.drive_id});return item
@app.post("/api/files/move")
async def move_api(body:TransferBody,request:Request,user:dict=Depends(csrf)):
    source=access_drive(user,body.source_drive_id,"MOVE",body.paths[0]);dest=access_drive(user,body.destination_drive_id,"UPLOAD",body.destination_path);items=safe_call("MOVE",user,request,body.source_drive_id,",".join(body.paths),lambda:move_or_copy(source,body.paths,dest,body.destination_path,False));threading.Thread(target=index_all,daemon=True).start();await hub.broadcast("files.changed",{"drive_id":body.source_drive_id});return {"items":items}
@app.post("/api/files/copy")
async def copy_api(body:TransferBody,request:Request,user:dict=Depends(csrf)):
    source=access_drive(user,body.source_drive_id,"COPY",body.paths[0]);dest=access_drive(user,body.destination_drive_id,"UPLOAD",body.destination_path);items=safe_call("COPY",user,request,body.source_drive_id,",".join(body.paths),lambda:move_or_copy(source,body.paths,dest,body.destination_path,True));threading.Thread(target=index_all,daemon=True).start();await hub.broadcast("files.changed",{"drive_id":body.destination_drive_id});return {"items":items}
@app.delete("/api/files")
async def delete_api(body:DeleteBody,request:Request,user:dict=Depends(csrf)):
    drive=access_drive(user,body.drive_id,"DELETE",body.paths[0]);ids=safe_call("TRASH",user,request,body.drive_id,",".join(body.paths),lambda:trash_items(drive,body.paths,user["id"]));threading.Thread(target=lambda:index_drive(drive),daemon=True).start();await hub.broadcast("files.changed",{"drive_id":body.drive_id});return {"trash_ids":ids}

@app.post("/api/files/upload/init")
def upload_init(body:UploadInit,request:Request,user:dict=Depends(csrf)):
    drive=access_drive(user,body.drive_id,"UPLOAD",body.path);name=validate_name(body.name);ensure_policy(drive,name,body.size);parent_rel,_=safe_path(drive,body.path,True);target_rel=normalize_relative("/".join(x for x in (parent_rel,name) if x));_,target=safe_path(drive,target_rel,None);existing=target.stat().st_size if target.exists() and target.is_file() else 0
    if target.exists():
        if target.is_dir():fail(409,"UPLOAD_CONFLICT","A folder with this name exists")
        if body.conflict_action=="error":fail(409,"UPLOAD_CONFLICT","A file with this name exists")
        if body.conflict_action=="keep_both":target_rel=unique_path(drive,parent_rel,name)
    if drive.get("quota_bytes"):
        used=db.one("SELECT COALESCE(SUM(size_bytes),0) n FROM file_metadata WHERE drive_id=? AND is_dir=0",(drive["id"],))["n"];added=body.size-(existing if body.conflict_action in {"replace","version"} else 0)
        if used+max(0,added)>drive["quota_bytes"]:fail(507,"DRIVE_QUOTA","Drive cloud quota would be exceeded")
    upload_id=uuid.uuid4().hex;temp=settings.temp_dir/f"upload-{upload_id}.part";temp.touch();expires=iso_after(24);db.execute("INSERT INTO upload_sessions(id,user_id,drive_id,target_path,temp_path,expected_size,received_size,conflict_action,created_at,expires_at) VALUES(?,?,?,?,?,?,0,?,?,?)",(upload_id,user["id"],body.drive_id,target_rel,str(temp),body.size,body.conflict_action,db.now_iso(),expires));db.audit("UPLOAD_INIT",target_rel,"SUCCESS",user,body.drive_id,ip_of(request));return {"upload_id":upload_id,"offset":0,"chunk_size":8*1024*1024,"expires_at":expires,"target_path":target_rel}
@app.put("/api/files/upload/{upload_id}")
async def upload_chunk(upload_id:str,request:Request,offset:int=Query(ge=0),user:dict=Depends(csrf)):
    row=db.one("SELECT * FROM upload_sessions WHERE id=? AND user_id=?",(upload_id,user["id"]))
    if not row:fail(404,"UPLOAD_NOT_FOUND","Upload session not found")
    if row["received_size"]!=offset:fail(409,"OFFSET_MISMATCH",f"Resume at offset {row['received_size']}")
    drive=access_drive(user,row["drive_id"],"UPLOAD",str(PurePosixPath(row["target_path"]).parent));temp=Path(row["temp_path"]);received=offset
    if not temp.exists() or temp.stat().st_size<offset:fail(409,"UPLOAD_STATE_INVALID","Upload temporary data is missing; restart this upload")
    try:
        with temp.open("r+b") as out:
            out.truncate(offset);out.seek(offset)
            async for chunk in request.stream():
                if not chunk:continue
                received+=len(chunk)
                if received>row["expected_size"]:raise ValueError("Upload exceeds declared size")
                if offset==0 and received==len(chunk):ensure_policy(drive,Path(row["target_path"]).name,row["expected_size"],chunk[:4096])
                out.write(chunk)
            out.flush();os.fsync(out.fileno())
        db.execute("UPDATE upload_sessions SET received_size=? WHERE id=?",(received,upload_id));return {"upload_id":upload_id,"offset":received,"complete":received==row["expected_size"]}
    except HTTPException:raise
    except Exception as e:
        try:
            with temp.open("r+b") as rollback:rollback.truncate(offset)
        except OSError:pass
        db.audit("UPLOAD_CHUNK",row["target_path"],"FAILED",user,row["drive_id"],ip_of(request),str(e));fail(400,"UPLOAD_FAILED",str(e))
@app.post("/api/files/upload/{upload_id}/complete")
async def upload_complete(upload_id:str,request:Request,user:dict=Depends(csrf)):
    row=db.one("SELECT * FROM upload_sessions WHERE id=? AND user_id=?",(upload_id,user["id"]))
    if not row:fail(404,"UPLOAD_NOT_FOUND","Upload session not found")
    if row["received_size"]!=row["expected_size"]:fail(409,"UPLOAD_INCOMPLETE",f"Received {row['received_size']} of {row['expected_size']} bytes")
    drive=access_drive(user,row["drive_id"],"UPLOAD",str(PurePosixPath(row["target_path"]).parent));rel,target=safe_path(drive,row["target_path"],None,False);temp=Path(row["temp_path"])
    try:
        action=row["conflict_action"] or "error"
        if target.exists():
            if action=="error":fail(409,"UPLOAD_CONFLICT","A file now exists at the upload target")
            if action=="keep_both":
                parent=str(PurePosixPath(rel).parent);parent="" if parent=="." else parent;rel=unique_path(drive,parent,target.name);_,target=safe_path(drive,rel,False)
            elif action=="version":save_version(drive,rel,target,user["id"],"upload_overwrite")
        os.replace(temp,target);db.execute("DELETE FROM upload_sessions WHERE id=?",(upload_id,));db.audit("UPLOAD",rel,"SUCCESS",user,drive["id"],ip_of(request),f"{row['expected_size']} bytes; conflict={action}");threading.Thread(target=lambda:process_arrival(user["id"],drive,rel,"upload"),daemon=True).start();threading.Thread(target=lambda:index_drive(drive),daemon=True).start();await hub.broadcast("files.changed",{"drive_id":drive["id"]});return describe(drive,rel,target)
    except HTTPException:raise
    except Exception as e:fail(500,"UPLOAD_COMMIT_FAILED",str(e))
@app.delete("/api/files/upload/{upload_id}")
def upload_cancel(upload_id:str,request:Request,user:dict=Depends(csrf)):
    row=db.one("SELECT * FROM upload_sessions WHERE id=? AND user_id=?",(upload_id,user["id"]))
    if row:
        Path(row["temp_path"]).unlink(missing_ok=True);db.execute("DELETE FROM upload_sessions WHERE id=?",(upload_id,));db.audit("UPLOAD_CANCEL",row["target_path"],"SUCCESS",user,row["drive_id"],ip_of(request))
    return {"ok":True}

@app.get("/api/files/download")
def download(drive_id:str,path:str,request:Request,user:dict=Depends(current_user)):
    drive=access_drive(user,drive_id,"DOWNLOAD",path);rel,p=safe_path(drive,path,True,False)
    if p.is_dir():
        output=settings.temp_dir/f"download-{uuid.uuid4().hex}.zip";make_zip(drive,[rel],output);db.audit("DOWNLOAD_ZIP",rel,"SUCCESS",user,drive_id,ip_of(request));return FileResponse(output,filename=p.name+".zip",background=BackgroundTask(output.unlink,missing_ok=True))
    db.execute("INSERT INTO recent_files(user_id,drive_id,relative_path,opened_at) VALUES(?,?,?,?) ON CONFLICT(user_id,drive_id,relative_path) DO UPDATE SET opened_at=excluded.opened_at",(user["id"],drive_id,rel,db.now_iso()));db.audit("DOWNLOAD",rel,"SUCCESS",user,drive_id,ip_of(request));return FileResponse(p,filename=p.name,media_type="application/octet-stream")
@app.post("/api/files/download-archive")
def download_archive(body:DeleteBody,request:Request,user:dict=Depends(csrf)):
    drive=access_drive(user,body.drive_id,"DOWNLOAD",body.paths[0]);output=settings.temp_dir/f"archive-{uuid.uuid4().hex}.zip";safe_call("DOWNLOAD_ARCHIVE",user,request,body.drive_id,",".join(body.paths),lambda:make_zip(drive,body.paths,output));return FileResponse(output,filename="cloud-download.zip",background=BackgroundTask(output.unlink,missing_ok=True))
@app.get("/api/files/preview")
def preview(drive_id:str,path:str,request:Request,user:dict=Depends(current_user)):
    drive=access_drive(user,drive_id,"PREVIEW",path);rel,p=safe_path(drive,path,True,False)
    if p.is_dir():fail(400,"NOT_PREVIEWABLE","Folders cannot be previewed")
    mime=mimetypes.guess_type(p.name)[0] or "application/octet-stream"
    if mime in {"text/html","application/javascript","image/svg+xml"}:mime="text/plain"
    db.execute("INSERT INTO recent_files(user_id,drive_id,relative_path,opened_at) VALUES(?,?,?,?) ON CONFLICT(user_id,drive_id,relative_path) DO UPDATE SET opened_at=excluded.opened_at",(user["id"],drive_id,rel,db.now_iso()));return FileResponse(p,media_type=mime,headers={"Content-Disposition":f'inline; filename="{p.name.replace(chr(34),"_")}"'})

@app.get("/api/files/thumbnail")
def file_thumbnail(drive_id:str,path:str,size:int=640,user:dict=Depends(current_user)):
    drive=access_drive(user,drive_id,"PREVIEW",path)
    try:return FileResponse(thumbnail(drive,path,size),media_type="image/jpeg")
    except ValueError as e:fail(415,"THUMBNAIL_UNAVAILABLE",str(e))
@app.get("/api/files/versions")
def versions_api(drive_id:str,path:str,user:dict=Depends(current_user)):access_drive(user,drive_id,"VIEW",path);return {"items":get_versions(drive_id,path)}
@app.get("/api/files/versions/{version_id}/download")
def version_download(version_id:str,user:dict=Depends(current_user)):
    row=get_version(version_id);drive=access_drive(user,row["drive_id"],"DOWNLOAD",row["relative_path"]);return FileResponse(version_file(drive,row),filename=Path(row["relative_path"]).name)
@app.post("/api/files/versions/{version_id}/restore")
async def version_restore(version_id:str,request:Request,user:dict=Depends(csrf)):
    row=get_version(version_id);drive=access_drive(user,row["drive_id"],"UPLOAD",row["relative_path"]);item=restore_version(drive,version_id,user["id"]);db.audit("VERSION_RESTORE",row["relative_path"],"SUCCESS",user,drive["id"],ip_of(request));threading.Thread(target=lambda:index_drive(drive),daemon=True).start();await hub.broadcast("files.changed",{"drive_id":drive["id"]});return item
@app.delete("/api/files/versions/{version_id}")
def version_delete(version_id:str,request:Request,user:dict=Depends(csrf)):
    row=get_version(version_id);drive=access_drive(user,row["drive_id"],"DELETE",row["relative_path"]);delete_version(drive,version_id);db.audit("VERSION_DELETE",row["relative_path"],"SUCCESS",user,drive["id"],ip_of(request));return {"ok":True}

@app.get("/api/search")
def search_api(q:str="",extension:str|None=None,min_size:int|None=None,max_size:int|None=None,drive_id:str|None=None,file_type:str|None=None,folder:str|None=None,modified_after:float|None=None,modified_before:float|None=None,favorite_only:bool=False,shared_only:bool=False,sort_by:str="name",direction:str="asc",offset:int=0,limit:int=200,user:dict=Depends(current_user)):
    ids=[d["id"] for d in list_drives(True) if "VIEW" in drive_permissions(user,d)];return {"items":index_search(q,ids,extension,min_size,max_size,drive_id,file_type,folder,modified_after,modified_before,favorite_only,shared_only,user["id"],sort_by,direction,offset,limit),"indexed_at":db.setting_get("last_index")}
@app.get("/api/favorites")
def favorites(user:dict=Depends(current_user)):
    rows=db.all("SELECT f.*,m.name,m.is_dir,m.size_bytes,m.modified_at,m.mime_type FROM favorites f LEFT JOIN file_metadata m ON m.drive_id=f.drive_id AND m.relative_path=f.relative_path WHERE f.user_id=? ORDER BY f.created_at DESC",(user["id"],));return {"items":[dict(x) for x in rows]}
@app.put("/api/favorites")
def favorite(body:FavoriteBody,request:Request,user:dict=Depends(csrf)):
    drive=access_drive(user,body.drive_id,"FAVORITE",body.path);rel,_=safe_path(drive,body.path,True)
    if body.favorite:db.execute("INSERT OR IGNORE INTO favorites(user_id,drive_id,relative_path,created_at) VALUES(?,?,?,?)",(user["id"],body.drive_id,rel,db.now_iso()))
    else:db.execute("DELETE FROM favorites WHERE user_id=? AND drive_id=? AND relative_path=?",(user["id"],body.drive_id,rel))
    return {"favorite":body.favorite}
@app.get("/api/recent")
def recent(user:dict=Depends(current_user)):
    rows=db.all("SELECT r.*,m.name,m.is_dir,m.size_bytes,m.modified_at,m.mime_type FROM recent_files r LEFT JOIN file_metadata m ON m.drive_id=r.drive_id AND m.relative_path=r.relative_path WHERE r.user_id=? ORDER BY r.opened_at DESC LIMIT 200",(user["id"],));return {"items":[dict(x) for x in rows]}
@app.delete("/api/recent")
def clear_recent(user:dict=Depends(csrf)):db.execute("DELETE FROM recent_files WHERE user_id=?",(user["id"],));return {"ok":True}

@app.get("/api/trash")
def trash(user:dict=Depends(current_user)):
    sql="SELECT t.*,d.display_name,d.letter FROM trash t JOIN drives d ON d.id=t.drive_id"+("" if user["role"]=="ADMIN" else " WHERE t.deleted_by=?")+" ORDER BY t.deleted_at DESC";rows=db.all(sql,() if user["role"]=="ADMIN" else (user["id"],));return {"items":[dict(x) for x in rows if "VIEW" in drive_permissions(user,get_drive(x["drive_id"],False))]}
@app.post("/api/trash/restore")
async def restore_trash(body:TrashBody,request:Request,user:dict=Depends(csrf)):
    restored=[]
    for tid in body.ids:
        row=db.one("SELECT * FROM trash WHERE id=?",(tid,));
        if not row:continue
        if user["role"]!="ADMIN" and row["deleted_by"]!=user["id"]:fail(403,"PERMISSION_DENIED","Not your trash item")
        drive=access_drive(user,row["drive_id"],"DELETE",row["original_path"]);source=Path(drive["root_path"])/".sol-trash"/row["trash_path"];rel,target=safe_path(drive,row["original_path"],False)
        target.parent.mkdir(parents=True,exist_ok=True);shutil.move(str(source),str(target));db.execute("DELETE FROM trash WHERE id=?",(tid,));restored.append(rel);db.audit("TRASH_RESTORE",rel,"SUCCESS",user,drive["id"],ip_of(request))
    threading.Thread(target=index_all,daemon=True).start();await hub.broadcast("files.changed",{});return {"restored":restored}
@app.delete("/api/trash/empty")
def empty_trash(request:Request,user:dict=Depends(csrf)):
    rows=db.all("SELECT * FROM trash"+("" if user["role"]=="ADMIN" else " WHERE deleted_by=?"),() if user["role"]=="ADMIN" else (user["id"],));deleted=0
    for row in rows:
        try:
            drive=access_drive(user,row["drive_id"],"DELETE",row["original_path"]);p=Path(drive["root_path"])/".sol-trash"/row["trash_path"]
            shutil.rmtree(p,ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True)
            db.execute("DELETE FROM trash WHERE id=?",(row["id"],));deleted+=1
        except HTTPException:continue
    db.audit("TRASH_EMPTY","trash","SUCCESS",user,ip=ip_of(request),detail=f"{deleted} items");return {"deleted":deleted}
@app.delete("/api/trash")
def permanent_trash(body:TrashBody,request:Request,user:dict=Depends(csrf)):
    count=0
    for tid in body.ids:
        row=db.one("SELECT * FROM trash WHERE id=?",(tid,));
        if not row:continue
        if user["role"]!="ADMIN" and row["deleted_by"]!=user["id"]:fail(403,"PERMISSION_DENIED","Not your trash item")
        drive=access_drive(user,row["drive_id"],"DELETE",row["original_path"]);p=Path(drive["root_path"])/".sol-trash"/row["trash_path"]
        if p.is_dir():shutil.rmtree(p,ignore_errors=True)
        else:p.unlink(missing_ok=True)
        db.execute("DELETE FROM trash WHERE id=?",(tid,));count+=1;db.audit("TRASH_DELETE",row["item_name"],"SUCCESS",user,drive["id"],ip_of(request))
    return {"deleted":count}

@app.post("/api/shares")
def create_share(body:ShareBody,request:Request,user:dict=Depends(csrf)):
    drive=access_drive(user,body.drive_id,"SHARE",body.path);rel,_=safe_path(drive,body.path,True);token=random_token(32);password_hash=hash_password(body.password) if body.password else None
    sid=db.execute("INSERT INTO shares(token_hash,token_hint,drive_id,relative_path,owner_id,mode,password_hash,expires_at,max_downloads,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",(token_hash(token),token[:8],body.drive_id,rel,user["id"],body.mode,password_hash,body.expires_at,body.max_downloads,db.now_iso()));db.audit("SHARE_CREATE",rel,"SUCCESS",user,body.drive_id,ip_of(request));return {"id":sid,"url":public_url(request,f"/share/{token}"),"token":token}
@app.get("/api/shares")
def shares(user:dict=Depends(current_user)):
    sql="SELECT s.id,s.token_hint,s.drive_id,s.relative_path,s.mode,s.expires_at,s.max_downloads,s.download_count,s.enabled,s.created_at,u.username FROM shares s JOIN users u ON u.id=s.owner_id"+("" if user["role"]=="ADMIN" else " WHERE s.owner_id=?")+" ORDER BY s.created_at DESC";rows=db.all(sql,() if user["role"]=="ADMIN" else (user["id"],));return {"items":[dict(x) for x in rows]}
@app.delete("/api/shares/{share_id}")
def disable_share(share_id:int,request:Request,user:dict=Depends(csrf)):
    row=db.one("SELECT * FROM shares WHERE id=?",(share_id,));
    if not row:fail(404,"SHARE_NOT_FOUND","Share not found")
    if user["role"]!="ADMIN" and row["owner_id"]!=user["id"]:fail(403,"PERMISSION_DENIED","Not your share")
    db.execute("UPDATE shares SET enabled=0 WHERE id=?",(share_id,));db.audit("SHARE_DISABLE",str(share_id),"SUCCESS",user,row["drive_id"],ip_of(request));return {"ok":True}
def share_row(token:str):
    row=db.one("SELECT * FROM shares WHERE token_hash=? AND enabled=1",(token_hash(token),))
    if not row:fail(404,"SHARE_NOT_FOUND","Share link is invalid or disabled")
    if row["expires_at"] and row["expires_at"]<db.now_iso():fail(410,"SHARE_EXPIRED","Share link expired")
    if row["max_downloads"] is not None and row["download_count"]>=row["max_downloads"]:fail(410,"SHARE_LIMIT","Download limit reached")
    return dict(row)
@app.get("/api/public/shares/{token}")
def share_info(token:str):
    row=share_row(token);drive=get_drive(row["drive_id"]);rel,p=safe_path(drive,row["relative_path"],True);return {"name":p.name,"is_dir":p.is_dir(),"mode":row["mode"],"requires_password":bool(row["password_hash"]),"expires_at":row["expires_at"]}
@app.post("/api/public/shares/{token}/access")
async def share_access(token:str,request:Request,response:Response):
    row=share_row(token);data=await request.json();password=str(data.get("password", ""))
    if row["password_hash"] and not verify_password(password,row["password_hash"]):fail(401,"SHARE_PASSWORD","Incorrect share password")
    proof=sign_payload({"share":row["id"],"exp":min((utcnow()+timedelta(hours=2)).timestamp(),datetime.fromisoformat(row["expires_at"]).timestamp() if row["expires_at"] else 9e15)});response.set_cookie("sol_share",proof,max_age=7200,httponly=True,secure=settings.cookie_secure,samesite="strict",path=f"/api/public/shares/{token}");return {"ok":True}
@app.get("/api/public/shares/{token}/download")
def share_download(token:str,request:Request):
    row=share_row(token);proof=verify_signed(request.cookies.get("sol_share", ""))
    if row["password_hash"] and (not proof or proof.get("share")!=row["id"]):fail(401,"SHARE_ACCESS_REQUIRED","Unlock this share first")
    drive=get_drive(row["drive_id"]);rel,p=safe_path(drive,row["relative_path"],True)
    with db.connection() as con:
        cursor=con.execute("UPDATE shares SET download_count=download_count+1 WHERE id=? AND (max_downloads IS NULL OR download_count<max_downloads)",(row["id"],))
        if cursor.rowcount!=1:fail(410,"SHARE_LIMIT","Download limit reached")
    if p.is_dir():output=settings.temp_dir/f"share-{uuid.uuid4().hex}.zip";make_zip(drive,[rel],output);return FileResponse(output,filename=p.name+".zip",background=BackgroundTask(output.unlink,missing_ok=True))
    return FileResponse(p,filename=p.name)

@app.get("/api/users")
def users(user:dict=Depends(require_admin)):return {"items":[{k:r[k] for k in ("id","username","display_name","role","enabled","created_at","last_login")} for r in db.all("SELECT * FROM users ORDER BY username COLLATE NOCASE")]}
@app.post("/api/users")
def create_user(body:UserBody,request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    try:username=validate_username(body.username);ph=hash_password(body.password);uid=db.execute("INSERT INTO users(username,display_name,password_hash,role,enabled,created_at) VALUES(?,?,?,?,?,?)",(username,body.display_name.strip(),ph,body.role,int(body.enabled),db.now_iso()))
    except ValueError as e:fail(400,"INVALID_USER",str(e))
    except Exception:fail(409,"USERNAME_EXISTS","Username already exists")
    db.audit("USER_CREATE",username,"SUCCESS",user,ip=ip_of(request));return {"id":uid}
@app.patch("/api/users/{user_id}")
async def patch_user(user_id:int,request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    target=db.one("SELECT * FROM users WHERE id=?",(user_id,))
    if not target:fail(404,"USER_NOT_FOUND","User not found")
    data=await request.json();allowed={k:data[k] for k in ("display_name","role","enabled") if k in data}
    if "role" in allowed and allowed["role"] not in ROLE_DEFAULTS:fail(400,"INVALID_ROLE","Invalid role")
    if "display_name" in allowed:
        allowed["display_name"]=str(allowed["display_name"]).strip()
        if not allowed["display_name"] or len(allowed["display_name"])>80:fail(400,"INVALID_DISPLAY_NAME","Display name must be 1 to 80 characters")
    if "enabled" in allowed and not isinstance(allowed["enabled"],bool):fail(400,"INVALID_ENABLED","Enabled must be true or false")
    if user_id==user["id"] and allowed.get("enabled") is False:fail(400,"SELF_DISABLE","You cannot disable your own account")
    removes_admin=target["role"]=="ADMIN" and (allowed.get("role",target["role"])!="ADMIN" or allowed.get("enabled",bool(target["enabled"])) is False)
    if removes_admin and db.one("SELECT COUNT(*) n FROM users WHERE role='ADMIN' AND enabled=1 AND id<>?",(user_id,))["n"]==0:fail(409,"LAST_ADMIN","The final active administrator cannot be disabled or demoted")
    if allowed:db.execute(f"UPDATE users SET {','.join(f'{k}=?' for k in allowed)} WHERE id=?",(*[int(v) if k=='enabled' else v for k,v in allowed.items()],user_id))
    db.audit("USER_UPDATE",str(user_id),"SUCCESS",user,ip=ip_of(request));return {"ok":True}
@app.put("/api/users/{user_id}/password")
def reset_password(user_id:int,body:PasswordBody,request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN" and user_id!=user["id"]:fail(403,"PERMISSION_DENIED","Cannot change this password")
    if not db.one("SELECT id FROM users WHERE id=?",(user_id,)):fail(404,"USER_NOT_FOUND","User not found")
    current_hash=token_hash(session_token(request) or "");db.execute("UPDATE users SET password_hash=? WHERE id=?",(hash_password(body.password),user_id));db.execute("DELETE FROM sessions WHERE user_id=? AND id_hash<>?",(user_id,current_hash));db.audit("PASSWORD_RESET",str(user_id),"SUCCESS",user,ip=ip_of(request));return {"ok":True}
@app.delete("/api/users/{user_id}")
def delete_user(user_id:int,request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    if user_id==user["id"]:fail(400,"SELF_DELETE","You cannot delete your own account")
    db.execute("DELETE FROM users WHERE id=?",(user_id,));db.audit("USER_DELETE",str(user_id),"SUCCESS",user,ip=ip_of(request));return {"ok":True}
@app.get("/api/permissions")
def permissions(user_id:int|None=None,user:dict=Depends(require_admin)):
    rows=db.all("SELECT p.*,u.username,d.display_name FROM permissions p JOIN users u ON u.id=p.user_id JOIN drives d ON d.id=p.drive_id"+(" WHERE p.user_id=?" if user_id else ""),(user_id,) if user_id else ());return {"items":[{**dict(x),"rules":json.loads(x["rules"])} for x in rows],"available":sorted(ALL_PERMISSIONS)}
@app.put("/api/permissions")
def put_permission(body:PermissionBody,request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    invalid=set(body.rules)-ALL_PERMISSIONS
    if invalid:fail(400,"INVALID_PERMISSION",f"Unknown permissions: {', '.join(invalid)}")
    folder=normalize_relative(body.folder_path);db.execute("INSERT INTO permissions(user_id,drive_id,folder_path,rules) VALUES(?,?,?,?) ON CONFLICT(user_id,drive_id,folder_path) DO UPDATE SET rules=excluded.rules",(body.user_id,body.drive_id,folder,json.dumps(body.rules)));db.audit("PERMISSION_UPDATE",f"{body.user_id}:{body.drive_id}:{folder}","SUCCESS",user,body.drive_id,ip_of(request));return {"ok":True}
@app.delete("/api/permissions/{permission_id}")
def delete_permission(permission_id:int,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    db.execute("DELETE FROM permissions WHERE id=?",(permission_id,));return {"ok":True}

@app.get("/api/dashboard")
def dashboard(user:dict=Depends(current_user)):
    drives=[d for d in list_drives(True) if "VIEW" in drive_permissions(user,d)];ids=[d["id"] for d in drives]
    if ids:
        marks=','.join('?' for _ in ids);summary=db.one(f"SELECT COALESCE(SUM(size_bytes),0) bytes,SUM(CASE WHEN is_dir=0 THEN 1 ELSE 0 END) files,SUM(CASE WHEN is_dir=1 THEN 1 ELSE 0 END) folders FROM file_metadata WHERE drive_id IN ({marks})",ids)
    else:summary={"bytes":0,"files":0,"folders":0}
    activity_sql="SELECT username,action,target,result,created_at FROM activity_logs"+("" if user["role"]=="ADMIN" else " WHERE user_id=?")+" ORDER BY created_at DESC LIMIT 12";activity=[dict(x) for x in db.all(activity_sql,() if user["role"]=="ADMIN" else (user["id"],))];recent_items=[dict(x) for x in db.all("SELECT r.*,m.name,m.size_bytes,m.mime_type FROM recent_files r LEFT JOIN file_metadata m ON m.drive_id=r.drive_id AND m.relative_path=r.relative_path WHERE r.user_id=? ORDER BY opened_at DESC LIMIT 8",(user["id"],))]
    return {"storage":{"total":sum(d["total_bytes"] for d in drives),"free":sum(d["free_bytes"] for d in drives),"cloud_bytes":summary["bytes"],"files":summary["files"],"folders":summary["folders"]},"drives":drives,"activity":activity,"recent":recent_items,"favorites":db.one("SELECT COUNT(*) n FROM favorites WHERE user_id=?",(user["id"],))["n"],"shares":db.one("SELECT COUNT(*) n FROM shares WHERE enabled=1 AND owner_id=?",(user["id"],))["n"],"trash":db.one("SELECT COUNT(*) n FROM trash")["n"]}
@app.get("/api/settings")
def get_settings(user:dict=Depends(current_user)):return {"app_name":db.setting_get("app_name",settings.app_name),"appearance":db.setting_get("appearance",{}),"general":db.setting_get("general",{}),"security":{"session_hours":settings.session_hours,"cookie_secure":settings.cookie_secure,"trusted_proxy":settings.trust_proxy_headers,"allowed_hosts":settings.allowed_hosts},"last_index":db.setting_get("last_index")}
@app.put("/api/settings")
async def put_settings(request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    data=await request.json()
    for key in ("app_name","appearance","general"):
        if key in data:db.setting_set(key,data[key])
    db.audit("SETTINGS_UPDATE","settings","SUCCESS",user,ip=ip_of(request));return get_settings(user)
@app.get("/api/admin/logs")
def logs(offset:int=0,limit:int=100,user:dict=Depends(require_admin)):
    return {"items":[dict(x) for x in db.all("SELECT * FROM activity_logs ORDER BY created_at DESC LIMIT ? OFFSET ?",(min(limit,500),offset))]}
@app.get("/api/admin/system")
def system(user:dict=Depends(require_admin)):
    memory={}
    try:
        import psutil
        vm=psutil.virtual_memory();memory={"total":vm.total,"available":vm.available,"percent":vm.percent,"cpu_percent":psutil.cpu_percent(interval=.1)}
    except Exception:memory={"total":None,"available":None,"percent":None,"cpu_percent":None}
    return {"os":platform.platform(),"system":platform.system(),"release":platform.release(),"machine":platform.machine(),"python":platform.python_version(),"hostname":socket.gethostname(),"cpu_count":os.cpu_count(),"memory":memory,"uptime_seconds":time.monotonic(),"version":__version__,"database":str(settings.database_path),"data_dir":str(settings.data_dir)}
@app.get("/api/admin/backup")
def backup(user:dict=Depends(require_admin)):
    stamp=datetime.now().strftime("%Y%m%d-%H%M%S");output=settings.temp_dir/f"sol-cloud-backup-{stamp}.zip"
    with zipfile.ZipFile(output,"w",zipfile.ZIP_DEFLATED) as z:
        z.write(settings.database_path,"cloud.db");secret=settings.data_dir/".session_secret"
        if secret.exists():z.write(secret,".session_secret")
        manifest={"version":__version__,"created_at":db.now_iso(),"includes_files":False};z.writestr("manifest.json",json.dumps(manifest,indent=2))
    return FileResponse(output,filename=output.name,background=BackgroundTask(output.unlink,missing_ok=True))




def update_result(fn):
    try:return fn()
    except updater.UpdateError as exc:
        status_code=502 if exc.code in {"UPDATE_CHECK_FAILED","UPDATE_DOWNLOAD_FAILED","UPDATE_HOST_UNREACHABLE"} else 422 if exc.code=="UPDATE_CHECKSUM_MISMATCH" else 400
        fail(status_code,exc.code,str(exc))

@app.get("/api/admin/updates/status")
def update_status(user:dict=Depends(require_admin)):return updater.status(__version__)
@app.put("/api/admin/updates/settings")
def update_settings_api(body:UpdateSettingsBody,request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    value=update_result(lambda:updater.save_update_settings(body.manifest_url,body.automatic_checks,body.check_hours));db.audit("UPDATE_SETTINGS","updates","SUCCESS",user,ip=ip_of(request));return value
@app.post("/api/admin/updates/check")
def update_check_api(request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    result=update_result(lambda:updater.check_remote(__version__,force=True));db.audit("UPDATE_CHECK","updates","SUCCESS",user,ip=ip_of(request));return result
@app.post("/api/admin/updates/download")
def update_download_api(request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    result=update_result(lambda:updater.download_and_stage(__version__));db.audit("UPDATE_STAGE",result["version"],"SUCCESS",user,ip=ip_of(request),detail=result["sha256"]);return result
@app.post("/api/admin/updates/upload")
async def update_upload_api(request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    declared=int(request.headers.get("content-length","0") or 0)
    if declared>updater.MAX_PACKAGE_BYTES:fail(413,"UPDATE_TOO_LARGE","The update package exceeds 256 MB")
    temp=settings.temp_dir/f"manual-update-{uuid.uuid4().hex}.zip";size=0
    try:
        with temp.open("wb") as output:
            async for chunk in request.stream():
                size+=len(chunk)
                if size>updater.MAX_PACKAGE_BYTES:fail(413,"UPDATE_TOO_LARGE","The update package exceeds 256 MB")
                output.write(chunk)
        result=update_result(lambda:updater.stage_package(temp,__version__,request.headers.get("x-update-sha256",""),"manual"));db.audit("UPDATE_STAGE",result["version"],"SUCCESS",user,ip=ip_of(request),detail=result["sha256"]);return result
    finally:temp.unlink(missing_ok=True)
@app.post("/api/admin/updates/dismiss")
def update_dismiss_api(body:UpdateVersionBody,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    return updater.skip_version(body.version)
@app.delete("/api/admin/updates/staged")
def update_discard_api(user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    updater.clear_staged();return {"ok":True}
@app.post("/api/admin/updates/install")
def update_install_api(body:UpdateInstallBody,request:Request,user:dict=Depends(csrf)):
    if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator access required")
    if os.name!="nt":fail(409,"WINDOWS_ONLY","One-click installation is supported on Windows; the package remains staged")
    staged=updater.status(__version__).get("staged")
    if not staged or staged.get("version")!=body.version or staged.get("sha256")!=body.sha256.lower():fail(409,"STAGED_UPDATE_CHANGED","The staged update changed; review it again")
    command=[sys.executable,str(BASE_DIR/"update_runner.py"),"--root",str(BASE_DIR),"--stage",staged["extract_dir"],"--pid",str(os.getpid()),"--expected-version",staged["version"]]
    flags=getattr(subprocess,"DETACHED_PROCESS",0)|getattr(subprocess,"CREATE_NEW_PROCESS_GROUP",0)
    try:subprocess.Popen(command,cwd=BASE_DIR,close_fds=True,creationflags=flags)
    except OSError as exc:fail(500,"UPDATE_LAUNCH_FAILED",str(exc))
    db.audit("UPDATE_INSTALL",staged["version"],"SUCCESS",user,ip=ip_of(request),detail="Installer scheduled");threading.Timer(1.5,lambda:os._exit(42)).start();return {"ok":True,"restarting":True,"version":staged["version"]}


@app.on_event("startup")
def start_sync_worker():
 def loop():
  while True:
   try:run_due_syncs(get_drive)
   except Exception:pass
   time.sleep(30)
 threading.Thread(target=loop,daemon=True).start()

@app.get("/service-worker.js")
def service_worker():return FileResponse(STATIC/"service-worker.js",media_type="application/javascript",headers={"Service-Worker-Allowed":"/","Cache-Control":"no-cache"})
@app.get("/api/transfers")
def transfers(user:dict=Depends(current_user)):
 active=[dict(x) for x in db.all("SELECT id,drive_id,target_path,expected_size,received_size,created_at,expires_at FROM upload_sessions WHERE user_id=? ORDER BY created_at DESC",(user["id"],))];history=[dict(x) for x in db.all("SELECT action,target,drive_id,result,detail,created_at FROM activity_logs WHERE user_id=? AND action IN ('UPLOAD','UPLOAD_INIT') ORDER BY created_at DESC LIMIT 100",(user["id"],))];return {"active":active,"history":history,"summary":{"active":len(active),"completed":sum(1 for x in history if x["action"]=="UPLOAD" and x["result"]=="SUCCESS"),"failed":sum(1 for x in history if x["result"]!="SUCCESS")}}
@app.delete("/api/transfers/{upload_id}")
def cancel_transfer(upload_id:str,user:dict=Depends(csrf)):
 r=db.one("SELECT * FROM upload_sessions WHERE id=? AND user_id=?",(upload_id,user["id"]));
 if not r:fail(404,"NOT_FOUND","Transfer not found")
 Path(r["temp_path"]).unlink(missing_ok=True);db.execute("DELETE FROM upload_sessions WHERE id=?",(upload_id,));return {"ok":True}
@app.get("/api/sync-pairs")
def sync_pairs(user:dict=Depends(require_admin)):return {"items":[dict(x) for x in db.all("SELECT * FROM sync_pairs ORDER BY name")]}
@app.post("/api/sync-pairs")
def sync_pair_create(body:SyncPairBody,user:dict=Depends(csrf)):
 if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator required")
 local=Path(body.local_path).expanduser().resolve();local.mkdir(parents=True,exist_ok=True);drive=access_drive(user,body.drive_id,"VIEW",body.cloud_path);_,cloud_root=safe_path(drive,body.cloud_path,None);cloud_root.mkdir(parents=True,exist_ok=True);sid=uuid.uuid4().hex;db.execute("INSERT INTO sync_pairs(id,name,local_path,drive_id,cloud_path,enabled,interval_seconds,created_at) VALUES(?,?,?,?,?,?,?,?)",(sid,body.name,str(local),body.drive_id,normalize_relative(body.cloud_path),int(body.enabled),body.interval_seconds,db.now_iso()));return {"id":sid}
@app.post("/api/sync-pairs/{pair_id}/run")
def sync_pair_run(pair_id:str,user:dict=Depends(csrf)):
 if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator required")
 r=db.one("SELECT * FROM sync_pairs WHERE id=?",(pair_id,));
 if not r:fail(404,"NOT_FOUND","Sync pair not found")
 return {"actions":run_sync(dict(r),get_drive(r["drive_id"]))}
@app.delete("/api/sync-pairs/{pair_id}")
def sync_pair_delete(pair_id:str,user:dict=Depends(csrf)):
 if user["role"]!="ADMIN":fail(403,"ADMIN_REQUIRED","Administrator required")
 db.execute("DELETE FROM sync_pairs WHERE id=?",(pair_id,));return {"ok":True}
@app.get("/api/file-requests")
def requests_list(user:dict=Depends(current_user)):return {"items":[dict(x) for x in db.all("SELECT * FROM file_requests WHERE owner_id=? ORDER BY created_at DESC",(user["id"],))]}
@app.post("/api/file-requests")
def request_create(body:FileRequestBody,request:Request,user:dict=Depends(csrf)):
 access_drive(user,body.drive_id,"SHARE",body.target_path);rid=uuid.uuid4().hex;token=random_token(24);password_hash=hash_password(body.password) if body.password else None;extensions=[x.lower() if x.startswith(".") else "."+x.lower() for x in body.allowed_extensions if x.strip()];db.execute("INSERT INTO file_requests(id,token,owner_id,drive_id,target_path,title,instructions,expires_at,max_bytes,max_uploads,password_hash,allowed_extensions,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(rid,token,user["id"],body.drive_id,normalize_relative(body.target_path),body.title,body.instructions,body.expires_at,body.max_bytes,body.max_uploads,password_hash,json.dumps(extensions),db.now_iso()));return {"id":rid,"url":public_url(request,"/request/"+token)}
@app.delete("/api/file-requests/{rid}")
def request_delete(rid:str,user:dict=Depends(csrf)):db.execute("UPDATE file_requests SET enabled=0 WHERE id=? AND owner_id=?",(rid,user["id"]));return {"ok":True}
@app.get("/api/public/request/{token}")
def request_info(token:str):
 r=db.one("SELECT id,title,instructions,expires_at,max_bytes,max_uploads,upload_count,password_hash,enabled FROM file_requests WHERE token=?",(token,));
 if not r or not r["enabled"] or (r["expires_at"] and r["expires_at"]<db.now_iso()):fail(404,"REQUEST_CLOSED","File request closed")
 data=dict(r);data["requires_password"]=bool(data.pop("password_hash",None));return data
@app.post("/api/public/request/{token}/upload/init")
def public_request_init(token:str,body:PublicRequestInit):
 r=db.one("SELECT * FROM file_requests WHERE token=? AND enabled=1",(token,))
 if not r or (r["expires_at"] and r["expires_at"]<db.now_iso()):fail(404,"REQUEST_CLOSED","File request closed")
 if r["max_uploads"] and r["upload_count"]>=r["max_uploads"]:fail(409,"REQUEST_FULL","This request reached its upload limit")
 if r["password_hash"] and (not body.password or not verify_password(body.password,r["password_hash"])):fail(401,"REQUEST_PASSWORD","Incorrect request password")
 drive=get_drive(r["drive_id"]);name=validate_name(body.name);allowed=json.loads(r["allowed_extensions"] or "[]")
 if allowed and Path(name).suffix.lower() not in allowed:fail(415,"REQUEST_FILE_TYPE","This file type is not accepted")
 limit=r["max_bytes"] or drive["max_upload_bytes"]
 if limit and body.size>limit:fail(413,"REQUEST_LIMIT","File exceeds this request's size limit")
 ensure_policy(drive,name,body.size);parent_rel,_=safe_path(drive,r["target_path"],True);target_rel=unique_path(drive,parent_rel,name);uid=uuid.uuid4().hex;temp=settings.temp_dir/f"request-{uid}.part";temp.touch();db.execute("INSERT INTO request_uploads(id,request_id,target_path,temp_path,expected_size,received_size,created_at) VALUES(?,?,?,?,?,0,?)",(uid,r["id"],target_rel,str(temp),body.size,db.now_iso()));return {"upload_id":uid,"offset":0,"chunk_size":8*1024*1024,"target_path":target_rel}
@app.put("/api/public/request/{token}/upload/{upload_id}")
async def public_request_chunk(token:str,upload_id:str,request:Request,offset:int=Query(ge=0)):
 row=db.one("SELECT u.* FROM request_uploads u JOIN file_requests r ON r.id=u.request_id WHERE u.id=? AND r.token=? AND r.enabled=1",(upload_id,token))
 if not row:fail(404,"UPLOAD_NOT_FOUND","Upload session not found")
 if offset!=row["received_size"]:fail(409,"OFFSET_MISMATCH",f"Expected offset {row['received_size']}")
 temp=Path(row["temp_path"]);received=0
 if not temp.exists() or temp.stat().st_size<offset:fail(409,"UPLOAD_STATE_INVALID","Upload temporary data is missing; restart this upload")
 try:
  with temp.open("r+b") as out:
   out.truncate(offset);out.seek(offset)
   async for chunk in request.stream():
    received+=len(chunk)
    if offset+received>row["expected_size"]:fail(413,"UPLOAD_TOO_LARGE","Upload exceeds declared size")
    out.write(chunk)
   out.flush();os.fsync(out.fileno())
 except HTTPException:
  with temp.open("r+b") as rollback:rollback.truncate(offset)
  raise
 except OSError as exc:
  try:
   with temp.open("r+b") as rollback:rollback.truncate(offset)
  except OSError:pass
  fail(500,"UPLOAD_FAILED",str(exc))
 db.execute("UPDATE request_uploads SET received_size=? WHERE id=?",(offset+received,upload_id));return {"offset":offset+received}
@app.post("/api/public/request/{token}/upload/{upload_id}/complete")
async def public_request_complete(token:str,upload_id:str):
 row=db.one("SELECT u.*,r.drive_id,r.owner_id,r.title FROM request_uploads u JOIN file_requests r ON r.id=u.request_id WHERE u.id=? AND r.token=? AND r.enabled=1",(upload_id,token))
 if not row:fail(404,"UPLOAD_NOT_FOUND","Upload session not found")
 if row["received_size"]!=row["expected_size"]:fail(409,"UPLOAD_INCOMPLETE","Upload is incomplete")
 drive=get_drive(row["drive_id"]);rel,target=safe_path(drive,row["target_path"],False);os.replace(row["temp_path"],target);db.execute("DELETE FROM request_uploads WHERE id=?",(upload_id,));db.execute("UPDATE file_requests SET upload_count=upload_count+1 WHERE id=?",(row["request_id"],));db.audit("FILE_REQUEST_UPLOAD",rel,"SUCCESS",{"id":row["owner_id"],"username":"file-request"},drive["id"],detail=f"{row['expected_size']} bytes");threading.Thread(target=lambda:process_arrival(row["owner_id"],drive,rel,"file-request"),daemon=True).start();threading.Thread(target=lambda:index_drive(drive),daemon=True).start();await hub.broadcast("files.changed",{"drive_id":drive["id"]});return {"ok":True,"name":Path(rel).name}


# --- 2.4 Intelligent Spatial Workspace APIs ---
def visible_drive_ids(user:dict)->list[str]:
 return [d['id'] for d in list_drives(True) if 'VIEW' in drive_permissions(user,d)]

@app.get('/api/tags')
def tags_api(user:dict=Depends(current_user)):return {'items':list_tags(user['id'])}
@app.post('/api/tags')
def tag_create_api(body:TagBody,user:dict=Depends(csrf)):
 try:return create_tag(user['id'],body.name,body.color)
 except ValueError as e:fail(400,'INVALID_TAG',str(e))
@app.delete('/api/tags/{tag_id}')
def tag_delete_api(tag_id:str,user:dict=Depends(csrf)):delete_tag(user['id'],tag_id);return {'ok':True}
@app.get('/api/files/tags')
def file_tags_api(drive_id:str,path:str,user:dict=Depends(current_user)):
 access_drive(user,drive_id,'VIEW',path);return {'items':file_tags(user['id'],drive_id,path)}
@app.put('/api/files/tags')
def file_tags_update_api(body:FileTagsBody,user:dict=Depends(csrf)):
 access_drive(user,body.drive_id,'VIEW',body.path);return {'items':set_file_tags(user['id'],body.drive_id,body.path,body.tag_ids)}

@app.get('/api/collections')
def collections_api(user:dict=Depends(current_user)):return {'items':list_collections(user['id'])}
@app.post('/api/collections')
def collection_create_api(body:CollectionBody,user:dict=Depends(csrf)):return {'id':create_collection(user['id'],body.name,body.criteria)}
@app.delete('/api/collections/{collection_id}')
def collection_delete_api(collection_id:str,user:dict=Depends(csrf)):delete_collection(user['id'],collection_id);return {'ok':True}
@app.get('/api/collections/{collection_id}/items')
def collection_items_api(collection_id:str,limit:int=300,user:dict=Depends(current_user)):
 items=collection_items(user['id'],collection_id,visible_drive_ids(user),limit)
 if items is None:fail(404,'COLLECTION_NOT_FOUND','Smart collection not found')
 return {'items':items}

@app.get('/api/inbox')
def inbox_api(status:str='NEW',user:dict=Depends(current_user)):return {'items':list_inbox(user['id'],status)}
@app.post('/api/inbox/resolve')
def inbox_resolve_api(body:InboxResolveBody,user:dict=Depends(csrf)):resolve_inbox(user['id'],body.ids,body.status);return {'ok':True}
@app.get('/api/notifications')
def notifications_api(limit:int=100,user:dict=Depends(current_user)):return notifications(user['id'],limit)
@app.post('/api/notifications/read')
def notifications_read_api(body:NotificationReadBody,user:dict=Depends(csrf)):mark_notifications(user['id'],body.ids,body.all);return {'ok':True}

@app.get('/api/intelligence/content-search')
def content_search_api(q:str,limit:int=100,user:dict=Depends(current_user)):return {'items':content_search(q,visible_drive_ids(user),limit)}
@app.post('/api/intelligence/content-index')
def content_index_api(body:ContentIndexBody,user:dict=Depends(csrf)):
 drive=access_drive(user,body.drive_id,'VIEW',body.path);return index_content(drive,body.path)
@app.post('/api/intelligence/scan')
def intelligence_scan_api(body:IntelligenceScanBody,user:dict=Depends(csrf)):
 if user['role']!='ADMIN':fail(403,'ADMIN_REQUIRED','Administrator access required for full scans')
 drives=[get_drive(body.drive_id)] if body.drive_id else [get_drive(x) for x in visible_drive_ids(user)];result={};total=0
 for drive in drives:
  r=scan_drive_intelligence(drive,body.max_files,body.content);result[drive['id']]=r;total+=r['scanned']
 return {'scanned':total,'drives':result}
@app.get('/api/duplicates')
def duplicates_api(limit:int=100,user:dict=Depends(current_user)):return {'items':duplicate_groups(visible_drive_ids(user),limit)}
@app.get('/api/storage/intelligence')
def storage_intelligence_api(user:dict=Depends(current_user)):return storage_intelligence(visible_drive_ids(user))

@app.get('/api/rules')
def rules_api(user:dict=Depends(current_user)):return {'items':list_rules(user['id'])}
@app.post('/api/rules')
def rule_create_api(body:RuleBody,user:dict=Depends(csrf)):return {'id':create_rule(user['id'],body.name,body.trigger,body.conditions,body.actions,body.enabled,body.dry_run)}
@app.delete('/api/rules/{rule_id}')
def rule_delete_api(rule_id:str,user:dict=Depends(csrf)):delete_rule(user['id'],rule_id);return {'ok':True}
@app.post('/api/rules/{rule_id}/run')
def rule_run_api(rule_id:str,body:RuleRunBody,user:dict=Depends(csrf)):
 drive=access_drive(user,body.drive_id,'MOVE' if body.execute else 'VIEW',body.path);return run_rule(user['id'],rule_id,drive,body.path,body.execute)
@app.get('/api/workspace/summary')
def workspace_summary_api(user:dict=Depends(current_user)):return workspace_summary(user['id'],visible_drive_ids(user))

@app.websocket("/api/events")
async def events(ws:WebSocket):
    token=ws.cookies.get("sol_session");row=db.one("SELECT user_id FROM sessions WHERE id_hash=? AND expires_at>?",(token_hash(token or ""),db.now_iso()))
    if not row:await ws.close(code=4401);return
    await hub.connect(ws)
    try:
        while True:await ws.receive_text()
    except WebSocketDisconnect:hub.disconnect(ws)

@app.get("/share/{token}",response_class=HTMLResponse)
def share_page(token:str):return (STATIC/"index.html").read_text("utf-8")
@app.get("/request/{token}",response_class=HTMLResponse)
def request_page(token:str):return (STATIC/"request.html").read_text("utf-8")
@app.get("/{route:path}",response_class=HTMLResponse)
def spa(route:str=""):
    if route.startswith("api/"):fail(404,"NOT_FOUND","API endpoint not found")
    return (STATIC/"index.html").read_text("utf-8")
