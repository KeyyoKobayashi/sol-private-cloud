from __future__ import annotations
import hashlib,mimetypes,os,shutil,subprocess,uuid
from pathlib import Path
from . import database as db
from .config import settings
from .filesystem import describe,normalize_relative,safe_path

INTERNAL='.sol-cloud'
def unique_path(drive,parent,name):
 parent=normalize_relative(parent);p=Path(name)
 for n in range(10000):
  candidate=name if n==0 else f'{p.stem} ({n}){p.suffix}'
  rel=normalize_relative('/'.join(x for x in (parent,candidate) if x))
  try:safe_path(drive,rel,False);return rel
  except FileExistsError:pass
 raise FileExistsError('Could not create a unique filename')
def _store(drive):
 p=Path(drive['root_path'])/INTERNAL/'versions';p.mkdir(parents=True,exist_ok=True);return p
def save_version(drive,rel,source,user_id,reason='overwrite'):
 if not source.is_file():raise ValueError('Only files can be versioned')
 vid=uuid.uuid4().hex;stored=vid+source.suffix.lower();dst=_store(drive)/stored;shutil.copy2(source,dst);st=source.stat()
 db.execute('INSERT INTO file_versions(id,drive_id,relative_path,stored_name,size_bytes,source_modified_at,created_by,created_at,reason) VALUES(?,?,?,?,?,?,?,?,?)',(vid,drive['id'],normalize_relative(rel),stored,st.st_size,str(st.st_mtime),user_id,db.now_iso(),reason));return vid
def get_versions(drive_id,rel):return [dict(x) for x in db.all('SELECT v.id,v.drive_id,v.relative_path,v.size_bytes,v.source_modified_at,v.created_at,v.reason,u.username created_by_name FROM file_versions v LEFT JOIN users u ON u.id=v.created_by WHERE v.drive_id=? AND v.relative_path=? ORDER BY v.created_at DESC',(drive_id,normalize_relative(rel)))]
def get_version(vid):
 r=db.one('SELECT * FROM file_versions WHERE id=?',(vid,))
 if not r:raise FileNotFoundError('Version not found')
 return dict(r)
def version_file(drive,row):
 p=_store(drive)/Path(row['stored_name']).name
 if not p.is_file():raise FileNotFoundError('Stored version is missing')
 return p
def restore_version(drive,vid,user_id):
 row=get_version(vid)
 if row['drive_id']!=drive['id']:raise PermissionError('Version belongs to another drive')
 rel,target=safe_path(drive,row['relative_path'],None,False);stored=version_file(drive,row)
 if target.exists():save_version(drive,rel,target,user_id,'before_restore')
 target.parent.mkdir(parents=True,exist_ok=True);tmp=target.with_name('.'+target.name+'.restore-'+uuid.uuid4().hex);shutil.copy2(stored,tmp);os.replace(tmp,target);return describe(drive,rel,target)
def delete_version(drive,vid):
 row=get_version(vid)
 if row['drive_id']!=drive['id']:raise PermissionError('Version belongs to another drive')
 version_file(drive,row).unlink(missing_ok=True);db.execute('DELETE FROM file_versions WHERE id=?',(vid,))
def can_thumbnail(path):
 m=mimetypes.guess_type(path.name)[0] or ''
 return m.startswith(('image/','video/')) or m=='application/pdf'
def thumbnail(drive,rel,size=640):
 rel,src=safe_path(drive,rel,True,False);size=max(160,min(int(size),1200))
 if not can_thumbnail(src):raise ValueError('Thumbnail unavailable for this file type')
 cache=settings.data_dir/'thumbnails';cache.mkdir(parents=True,exist_ok=True);key=hashlib.sha256(f"{drive['id']}|{rel}|{src.stat().st_mtime}|{size}".encode()).hexdigest();out=cache/(key+'.jpg')
 if out.exists() and out.stat().st_size:return out
 tmp=cache/(key+'.tmp.jpg');mime=mimetypes.guess_type(src.name)[0] or ''
 try:
  if mime.startswith('image/'):
   from PIL import Image,ImageOps
   with Image.open(src) as im:
    im=ImageOps.exif_transpose(im);im.thumbnail((size,size),Image.Resampling.LANCZOS)
    if im.mode not in ('RGB','L'):
     bg=Image.new('RGB',im.size,'#101010');bg.paste(im,mask=im.getchannel('A') if 'A' in im.getbands() else None);im=bg
    if im.mode=='L':im=im.convert('RGB')
    im.save(tmp,'JPEG',quality=84,optimize=True)
  elif mime=='application/pdf':
   import fitz
   doc=fitz.open(src)
   try:
    page=doc.load_page(0);zoom=min(2,max(.5,size/max(page.rect.width,page.rect.height)));page.get_pixmap(matrix=fitz.Matrix(zoom,zoom),alpha=False).save(str(tmp))
   finally:doc.close()
  else:
   ffmpeg=shutil.which('ffmpeg')
   if not ffmpeg:raise ValueError('Video thumbnails require FFmpeg')
   subprocess.run([ffmpeg,'-hide_banner','-loglevel','error','-y','-ss','00:00:01','-i',str(src),'-frames:v','1','-vf',f"scale='min({size},iw)':-2",str(tmp)],check=True,timeout=45)
  os.replace(tmp,out);return out
 finally:tmp.unlink(missing_ok=True)
def prewarm(drive,rel):
 try:thumbnail(drive,rel,480)
 except Exception:pass
