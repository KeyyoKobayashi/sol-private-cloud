from __future__ import annotations
import os, secrets
from dataclasses import dataclass, field
from pathlib import Path
BASE_DIR=Path(__file__).resolve().parent.parent
def env_bool(name,default=False):return os.getenv(name,str(default)).lower() in {'1','true','yes','on'}
def env_list(name,default=''):return [x.strip() for x in os.getenv(name,default).split(',') if x.strip()]
@dataclass(slots=True)
class Settings:
 app_name:str=field(default_factory=lambda:os.getenv('APP_NAME','Sol Private Cloud'))
 host:str=field(default_factory=lambda:os.getenv('HOST','127.0.0.1'));port:int=field(default_factory=lambda:int(os.getenv('PORT','8000')))
 data_dir:Path=field(default_factory=lambda:Path(os.getenv('DATA_DIR',str(BASE_DIR/'data'))).resolve());database_path:Path=field(init=False);temp_dir:Path=field(init=False);log_dir:Path=field(init=False)
 session_secret:str=field(default_factory=lambda:os.getenv('SESSION_SECRET',''));session_hours:int=field(default_factory=lambda:int(os.getenv('SESSION_HOURS','12')));cookie_secure:bool=field(default_factory=lambda:env_bool('COOKIE_SECURE'))
 trusted_proxy:str=field(default_factory=lambda:os.getenv('TRUSTED_PROXY','127.0.0.1'));trust_proxy_headers:bool=field(default_factory=lambda:env_bool('TRUST_PROXY_HEADERS'));allowed_hosts:list[str]=field(default_factory=lambda:env_list('ALLOWED_HOSTS','localhost,127.0.0.1'));cors_origins:list[str]=field(default_factory=lambda:env_list('CORS_ORIGINS'))
 public_base_url:str=field(default_factory=lambda:os.getenv('PUBLIC_BASE_URL','').rstrip('/'));default_max_upload_mb:int=field(default_factory=lambda:int(os.getenv('DEFAULT_MAX_UPLOAD_MB','4096')));index_interval_seconds:int=field(default_factory=lambda:int(os.getenv('INDEX_INTERVAL_SECONDS','300')));trash_retention_days:int=field(default_factory=lambda:int(os.getenv('TRASH_RETENTION_DAYS','30')));debug:bool=field(default_factory=lambda:env_bool('DEBUG'))
 def __post_init__(self):
  self.data_dir.mkdir(parents=True,exist_ok=True);self.temp_dir=self.data_dir/'tmp';self.temp_dir.mkdir(exist_ok=True);self.log_dir=self.data_dir/'logs';self.log_dir.mkdir(exist_ok=True);self.database_path=self.data_dir/'cloud.db';secret=self.data_dir/'.session_secret'
  if not self.session_secret:
   if secret.exists():self.session_secret=secret.read_text('utf-8').strip()
   else:self.session_secret=secrets.token_hex(48);secret.write_text(self.session_secret,'utf-8')
settings=Settings()
