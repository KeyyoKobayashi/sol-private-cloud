import mimetypes,os,threading
from pathlib import Path
from . import database as db
from .drive_manager import list_drives
from .filesystem import normalize_relative,_is_reparse,_hidden
from .advanced import can_thumbnail,prewarm
lock=threading.Lock();INTERNAL={'.sol-trash','.sol-cloud','.sol-sync-trash'}
def index_drive(drive,max_items=500000):
 if not drive.get('enabled') or not drive.get('online') or not drive.get('root_path'):return {'indexed':0,'skipped':True}
 root=Path(drive['root_path']);rows=[];thumbs=[];stamp=db.now_iso();count=0
 with lock:
  for current,dirs,files in os.walk(root,followlinks=False):
   dirs[:]=[d for d in dirs if d not in INTERNAL and not _is_reparse(Path(current)/d) and (drive['show_hidden'] or not _hidden(Path(current)/d))]
   for name,is_dir in [(d,True) for d in dirs]+[(f,False) for f in files]:
    if count>=max_items:break
    p=Path(current)/name
    try:
     if _is_reparse(p) or (not drive['show_hidden'] and _hidden(p)):continue
     rel=normalize_relative(p.relative_to(root).as_posix());st=p.stat();mime=None if is_dir else mimetypes.guess_type(name)[0] or 'application/octet-stream';rows.append((drive['id'],rel,name,p.suffix.lower(),int(is_dir),0 if is_dir else st.st_size,str(st.st_mtime),mime,stamp));count+=1
     if not is_dir and len(thumbs)<250 and can_thumbnail(p):thumbs.append(rel)
    except:pass
   if count>=max_items:break
  with db.connection() as con:con.execute('DELETE FROM file_metadata WHERE drive_id=?',(drive['id'],));con.executemany('INSERT INTO file_metadata(drive_id,relative_path,name,extension,is_dir,size_bytes,modified_at,mime_type,indexed_at) VALUES(?,?,?,?,?,?,?,?,?)',rows)
 for rel in thumbs:prewarm(drive,rel)
 return {'indexed':count,'thumbnails':len(thumbs),'skipped':False}
def index_all():
 result={}
 for d in list_drives(True):
  try:result[d['id']]=index_drive(d)
  except Exception as e:result[d['id']]={'error':str(e)}
 db.setting_set('last_index',{'time':db.now_iso(),'result':result});return result
def search(query,user_drive_ids,extension=None,min_size=None,max_size=None,drive_id=None,file_type=None,folder=None,modified_after=None,modified_before=None,favorite_only=False,shared_only=False,user_id=None,sort_by='name',direction='asc',offset=0,limit=200):
 if not user_drive_ids:return []
 where=[f"m.drive_id IN ({','.join('?' for _ in user_drive_ids)})"];params=[*user_drive_ids]
 if query:where.append('(m.name LIKE ? OR m.relative_path LIKE ?)');params.extend([f'%{query}%',f'%{query}%'])
 if extension:where.append('m.extension=?');params.append(extension if extension.startswith('.') else '.'+extension)
 if min_size is not None:where.append('m.size_bytes>=?');params.append(min_size)
 if max_size is not None:where.append('m.size_bytes<=?');params.append(max_size)
 if drive_id:where.append('m.drive_id=?');params.append(drive_id)
 if folder:
  folder=normalize_relative(folder);where.append('(m.relative_path=? OR m.relative_path LIKE ?)');params.extend([folder,folder+'/%'])
 if modified_after is not None:where.append('CAST(m.modified_at AS REAL)>=?');params.append(modified_after)
 if modified_before is not None:where.append('CAST(m.modified_at AS REAL)<=?');params.append(modified_before)
 types={'folder':'m.is_dir=1','image':"m.is_dir=0 AND m.mime_type LIKE 'image/%'",'video':"m.is_dir=0 AND m.mime_type LIKE 'video/%'",'audio':"m.is_dir=0 AND m.mime_type LIKE 'audio/%'",'pdf':"m.is_dir=0 AND m.mime_type='application/pdf'",'archive':"m.is_dir=0 AND m.extension IN ('.zip','.7z','.rar','.tar','.gz')",'document':"m.is_dir=0 AND (m.mime_type LIKE 'text/%' OR m.extension IN ('.doc','.docx','.xls','.xlsx','.ppt','.pptx','.md','.rtf'))",'code':"m.is_dir=0 AND m.extension IN ('.py','.js','.ts','.html','.css','.json','.java','.c','.cpp','.cs','.go','.rs','.php','.rb','.sh')"}
 if file_type in types:where.append(types[file_type])
 if favorite_only and user_id is not None:where.append('EXISTS (SELECT 1 FROM favorites f WHERE f.user_id=? AND f.drive_id=m.drive_id AND f.relative_path=m.relative_path)');params.append(user_id)
 if shared_only and user_id is not None:where.append('EXISTS (SELECT 1 FROM shares s WHERE s.owner_id=? AND s.enabled=1 AND s.drive_id=m.drive_id AND s.relative_path=m.relative_path)');params.append(user_id)
 orders={'name':'m.name COLLATE NOCASE','size':'m.size_bytes','modified':'CAST(m.modified_at AS REAL)','type':'m.extension COLLATE NOCASE'};order=orders.get(sort_by,orders['name']);direction='DESC' if direction=='desc' else 'ASC';params.extend([max(0,offset),min(max(1,limit),500)])
 sql='SELECT m.*,d.display_name drive_name,d.letter drive_letter FROM file_metadata m JOIN drives d ON d.id=m.drive_id WHERE '+' AND '.join(where)+f' ORDER BY m.is_dir DESC,{order} {direction} LIMIT ?,?'
 return [dict(r) for r in db.all(sql,params)]
