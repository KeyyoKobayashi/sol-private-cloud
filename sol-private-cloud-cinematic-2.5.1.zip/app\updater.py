from __future__ import annotations

import hashlib
import ipaddress
import json
import os
import re
import shutil
import socket
import ssl
import tempfile
import threading
import urllib.parse
import urllib.request
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from . import database as db
from .config import BASE_DIR, settings

MAX_MANIFEST_BYTES = 1024 * 1024
MAX_PACKAGE_BYTES = 256 * 1024 * 1024
MAX_UNPACKED_BYTES = 1024 * 1024 * 1024
MAX_ARCHIVE_FILES = 5000
REQUIRED_FILES = {"app/__init__.py", "run.py", "requirements.txt", "start.bat", "update_runner.py", "release-manifest.json"}
PROTECTED_ROOTS = {"data", ".env", ".venv", "ngrok.exe"}
HEX64 = re.compile(r"^[0-9a-fA-F]{64}$")
VERSION = re.compile(r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:[-+][0-9A-Za-z.-]+)?$")
_state_lock = threading.RLock()


class UpdateError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def utc_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def version_tuple(value: str) -> tuple[int, int, int]:
    match = VERSION.fullmatch(str(value or "").strip())
    if not match:
        raise UpdateError("INVALID_VERSION", "Version must use semantic versioning, for example 2.5.0")
    return tuple(int(match.group(i)) for i in range(1, 4))


def newer(candidate: str, current: str) -> bool:
    return version_tuple(candidate) > version_tuple(current)


def _update_dir() -> Path:
    path = settings.data_dir / "updates"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _state_path() -> Path:
    return _update_dir() / "state.json"


def read_state() -> dict[str, Any]:
    with _state_lock:
        try:
            value = json.loads(_state_path().read_text("utf-8"))
            return value if isinstance(value, dict) else {}
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {}


def write_state(value: dict[str, Any]) -> None:
    with _state_lock:
        path = _state_path()
        temp = path.with_suffix(".tmp")
        temp.write_text(json.dumps(value, indent=2, ensure_ascii=False), "utf-8")
        os.replace(temp, path)


def update_settings() -> dict[str, Any]:
    raw = db.setting_get("update_settings", {}) or {}
    return {
        "manifest_url": str(raw.get("manifest_url", "")).strip(),
        "automatic_checks": bool(raw.get("automatic_checks", True)),
        "check_hours": min(168, max(1, int(raw.get("check_hours", 24)))),
        "skipped_version": str(raw.get("skipped_version", "")),
    }


def save_update_settings(manifest_url: str, automatic_checks: bool, check_hours: int) -> dict[str, Any]:
    manifest_url = manifest_url.strip()
    if manifest_url:
        validate_public_https_url(manifest_url)
    current = update_settings()
    previous_url = current["manifest_url"]
    current.update({
        "manifest_url": manifest_url,
        "automatic_checks": bool(automatic_checks),
        "check_hours": min(168, max(1, int(check_hours))),
    })
    db.setting_set("update_settings", current)
    if previous_url != manifest_url:
        state = read_state(); state.pop("latest", None); state.pop("last_check", None); state["last_error"] = ""; write_state(state)
    return current


def skip_version(version: str) -> dict[str, Any]:
    version_tuple(version)
    current = update_settings()
    current["skipped_version"] = version
    db.setting_set("update_settings", current)
    return current


def _host_is_public(host: str) -> bool:
    try:
        addresses = {item[4][0] for item in socket.getaddrinfo(host, None, type=socket.SOCK_STREAM)}
    except socket.gaierror as exc:
        raise UpdateError("UPDATE_HOST_UNREACHABLE", "The update host could not be resolved") from exc
    if not addresses:
        return False
    for value in addresses:
        ip = ipaddress.ip_address(value.split("%", 1)[0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_multicast or ip.is_reserved or ip.is_unspecified:
            return False
    return True


def validate_public_https_url(value: str) -> str:
    try:
        parsed = urllib.parse.urlsplit(value)
    except ValueError as exc:
        raise UpdateError("INVALID_UPDATE_URL", "The update URL is invalid") from exc
    if parsed.scheme.lower() != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise UpdateError("INVALID_UPDATE_URL", "Update URLs must use public HTTPS without embedded credentials")
    try: port = parsed.port
    except ValueError as exc: raise UpdateError("INVALID_UPDATE_URL", "The update URL contains an invalid port") from exc
    if port not in (None, 443):
        raise UpdateError("INVALID_UPDATE_URL", "Only the standard HTTPS port is allowed for updates")
    if not _host_is_public(parsed.hostname):
        raise UpdateError("PRIVATE_UPDATE_HOST", "Private, local, and reserved update hosts are not allowed")
    return value


class _SafeRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        validate_public_https_url(newurl)
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _open_public_https(url: str, timeout: int = 15):
    validate_public_https_url(url)
    request = urllib.request.Request(url, headers={"User-Agent": "Sol-Private-Cloud-Updater/2.5", "Accept": "application/json, application/zip"})
    opener = urllib.request.build_opener(urllib.request.HTTPSHandler(context=ssl.create_default_context()), _SafeRedirect())
    response = opener.open(request, timeout=timeout)
    validate_public_https_url(response.geturl())
    return response


def normalize_manifest(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise UpdateError("INVALID_MANIFEST", "The update manifest must be a JSON object")
    version = str(raw.get("version", "")).strip()
    version_tuple(version)
    url = validate_public_https_url(str(raw.get("download_url", "")).strip())
    sha256 = str(raw.get("sha256", "")).strip().lower()
    if not HEX64.fullmatch(sha256):
        raise UpdateError("INVALID_MANIFEST", "The update manifest must contain a SHA-256 checksum")
    minimum = str(raw.get("minimum_version", raw.get("min_version", "0.0.0"))).strip()
    version_tuple(minimum)
    notes = raw.get("release_notes", "")
    if isinstance(notes, list):
        notes = "\n".join(str(item) for item in notes[:100])
    notes = str(notes)[:20000]
    return {
        "version": version,
        "download_url": url,
        "sha256": sha256,
        "minimum_version": minimum,
        "release_notes": notes,
        "required": bool(raw.get("required", False)),
        "published_at": str(raw.get("published_at", ""))[:100],
    }


def fetch_manifest(url: str) -> dict[str, Any]:
    try:
        with _open_public_https(url) as response:
            declared = int(response.headers.get("Content-Length", "0") or 0)
            if declared > MAX_MANIFEST_BYTES:
                raise UpdateError("MANIFEST_TOO_LARGE", "The update manifest is too large")
            payload = response.read(MAX_MANIFEST_BYTES + 1)
    except UpdateError:
        raise
    except Exception as exc:
        raise UpdateError("UPDATE_CHECK_FAILED", "The update server could not be reached securely") from exc
    if len(payload) > MAX_MANIFEST_BYTES:
        raise UpdateError("MANIFEST_TOO_LARGE", "The update manifest is too large")
    try:
        return normalize_manifest(json.loads(payload.decode("utf-8")))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise UpdateError("INVALID_MANIFEST", "The update manifest is not valid UTF-8 JSON") from exc


def _notify_admins(manifest: dict[str, Any]) -> None:
    key = "update_notified_" + manifest["version"]
    if db.setting_get(key, False):
        return
    for row in db.all("SELECT id FROM users WHERE role='ADMIN' AND enabled=1"):
        db.execute("INSERT INTO notifications(id,user_id,kind,title,message,action_url,is_read,created_at) VALUES(?,?,?,?,?,?,0,?)", (
            uuid.uuid4().hex, row["id"], "update", f"Sol Cloud {manifest['version']} is available",
            "Review the release and install it from Administration → Updates.", "/admin/updates", db.now_iso()))
    db.setting_set(key, True)


def check_remote(current_version: str, force: bool = False) -> dict[str, Any]:
    config = update_settings()
    url = config["manifest_url"]
    if not url:
        return status(current_version) | {"check_result": "not_configured"}
    state = read_state()
    if not force and state.get("last_check"):
        try:
            age = datetime.now(timezone.utc) - datetime.fromisoformat(state["last_check"])
            if age.total_seconds() < config["check_hours"] * 3600:
                return status(current_version) | {"check_result": "cached"}
        except (ValueError, TypeError):
            pass
    manifest = fetch_manifest(url)
    compatible = version_tuple(current_version) >= version_tuple(manifest["minimum_version"])
    manifest["available"] = newer(manifest["version"], current_version)
    manifest["compatible"] = compatible
    manifest["skipped"] = config["skipped_version"] == manifest["version"]
    state["latest"] = manifest
    state["last_check"] = utc_iso()
    state["last_error"] = ""
    write_state(state)
    if manifest["available"] and compatible and not manifest["skipped"]:
        _notify_admins(manifest)
    return status(current_version) | {"check_result": "fresh"}


def automatic_check_due(current_version: str) -> None:
    config = update_settings()
    if not config["automatic_checks"] or not config["manifest_url"]:
        return
    try:
        check_remote(current_version, force=False)
    except Exception as exc:
        state = read_state()
        state["last_check"] = utc_iso()
        state["last_error"] = str(exc)[:500]
        write_state(state)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_archive_name(name: str) -> str:
    if "\\" in name or "\x00" in name:
        raise UpdateError("UNSAFE_UPDATE_PACKAGE", "The update archive contains an unsafe path")
    path = PurePosixPath(name)
    if path.is_absolute() or any(part in ("", ".", "..") for part in path.parts):
        raise UpdateError("UNSAFE_UPDATE_PACKAGE", "The update archive contains an unsafe path")
    devices={"CON","PRN","AUX","NUL",*(f"COM{i}" for i in range(1,10)),*(f"LPT{i}" for i in range(1,10))}
    for part in path.parts:
        if any(ord(ch)<32 or ch in '<>:"|?*' for ch in part) or part.endswith((" ",".")) or part.split(".",1)[0].upper() in devices:
            raise UpdateError("UNSAFE_UPDATE_PACKAGE", "The update archive contains a Windows-unsafe filename")
    return path.as_posix().rstrip("/")


def _archive_prefix(names: list[str]) -> str:
    roots = {PurePosixPath(name).parts[0] for name in names}
    if len(roots) == 1:
        root = next(iter(roots))
        if not any(name == "app/__init__.py" for name in names) and any(name.startswith(root + "/app/") for name in names):
            return root + "/"
    return ""


def stage_package(path: Path, current_version: str, expected_sha256: str = "", source: str = "manual") -> dict[str, Any]:
    if not path.is_file() or path.stat().st_size <= 0:
        raise UpdateError("INVALID_UPDATE_PACKAGE", "The update package is empty")
    if path.stat().st_size > MAX_PACKAGE_BYTES:
        raise UpdateError("UPDATE_TOO_LARGE", "The update package exceeds 256 MB")
    actual = sha256_file(path)
    if expected_sha256:
        expected_sha256 = expected_sha256.strip().lower()
        if not HEX64.fullmatch(expected_sha256) or actual != expected_sha256:
            raise UpdateError("UPDATE_CHECKSUM_MISMATCH", "The downloaded update failed SHA-256 verification")
    stage_id = uuid.uuid4().hex
    stage_root = _update_dir() / "staging" / stage_id
    extracted = stage_root / "extracted"
    extracted.mkdir(parents=True, exist_ok=False)
    try:
        with zipfile.ZipFile(path) as archive:
            infos = archive.infolist()
            if len(infos) > MAX_ARCHIVE_FILES:
                raise UpdateError("UPDATE_TOO_COMPLEX", "The update archive contains too many files")
            names = [_safe_archive_name(item.filename) for item in infos if not item.is_dir()]
            prefix = _archive_prefix(names)
            total = 0
            normalized: list[tuple[zipfile.ZipInfo, str]] = []; seen_names: set[str] = set()
            for item in infos:
                raw = _safe_archive_name(item.filename)
                if item.is_dir():
                    continue
                mode = (item.external_attr >> 16) & 0o170000
                if mode == 0o120000:
                    raise UpdateError("UNSAFE_UPDATE_PACKAGE", "Symbolic links are not allowed in update packages")
                relative = raw[len(prefix):] if prefix and raw.startswith(prefix) else raw
                first = PurePosixPath(relative).parts[0].lower()
                if first in PROTECTED_ROOTS:
                    raise UpdateError("PROTECTED_UPDATE_PATH", f"Updates cannot replace {first}")
                key=relative.casefold()
                if key in seen_names: raise UpdateError("UNSAFE_UPDATE_PACKAGE", "The update archive contains duplicate or case-colliding paths")
                seen_names.add(key); total += item.file_size
                if total > MAX_UNPACKED_BYTES:
                    raise UpdateError("UPDATE_TOO_LARGE", "The expanded update exceeds 1 GB")
                normalized.append((item, relative))
            available = {name for _, name in normalized}
            missing = REQUIRED_FILES - available
            if missing:
                raise UpdateError("INCOMPLETE_UPDATE_PACKAGE", "Required update files are missing: " + ", ".join(sorted(missing)))
            for item, relative in normalized:
                destination = extracted.joinpath(*PurePosixPath(relative).parts)
                destination.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(item) as source_file, destination.open("wb") as output:
                    shutil.copyfileobj(source_file, output, 1024 * 1024)
        release = json.loads((extracted / "release-manifest.json").read_text("utf-8"))
        version = str(release.get("version", "")).strip()
        minimum = str(release.get("minimum_version", release.get("min_version", "0.0.0"))).strip()
        version_tuple(version); version_tuple(minimum)
        if not newer(version, current_version):
            raise UpdateError("UPDATE_NOT_NEWER", f"Version {version} is not newer than {current_version}")
        if version_tuple(current_version) < version_tuple(minimum):
            raise UpdateError("UPDATE_INCOMPATIBLE", f"This update requires version {minimum} or newer")
        package_copy = stage_root / "package.zip"
        shutil.copy2(path, package_copy)
        record = {
            "id": stage_id,
            "version": version,
            "minimum_version": minimum,
            "sha256": actual,
            "size_bytes": path.stat().st_size,
            "source": source,
            "release_notes": str(release.get("release_notes", ""))[:20000],
            "staged_at": utc_iso(),
            "extract_dir": str(extracted),
            "package_path": str(package_copy),
        }
        state = read_state()
        previous = state.get("staged") or {}
        state["staged"] = record
        write_state(state)
        old_dir = Path(str(previous.get("extract_dir", ""))).parent
        if old_dir.exists() and old_dir != stage_root and _update_dir() in old_dir.parents:
            shutil.rmtree(old_dir, ignore_errors=True)
        return record
    except UpdateError:
        shutil.rmtree(stage_root, ignore_errors=True); raise
    except (zipfile.BadZipFile, json.JSONDecodeError, UnicodeDecodeError, OSError, KeyError, TypeError) as exc:
        shutil.rmtree(stage_root, ignore_errors=True)
        raise UpdateError("INVALID_UPDATE_PACKAGE", "The update ZIP or release manifest is invalid") from exc


def download_and_stage(current_version: str) -> dict[str, Any]:
    state = read_state()
    manifest = state.get("latest")
    if not isinstance(manifest, dict) or not manifest.get("available"):
        raise UpdateError("NO_UPDATE_AVAILABLE", "Check for updates before downloading")
    if not manifest.get("compatible"):
        raise UpdateError("UPDATE_INCOMPATIBLE", "This update cannot be installed directly from the current version")
    destination = _update_dir() / ("download-" + uuid.uuid4().hex + ".zip")
    try:
        with _open_public_https(manifest["download_url"], timeout=60) as response, destination.open("wb") as output:
            declared = int(response.headers.get("Content-Length", "0") or 0)
            if declared > MAX_PACKAGE_BYTES:
                raise UpdateError("UPDATE_TOO_LARGE", "The update package exceeds 256 MB")
            count = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                count += len(chunk)
                if count > MAX_PACKAGE_BYTES:
                    raise UpdateError("UPDATE_TOO_LARGE", "The update package exceeds 256 MB")
                output.write(chunk)
        return stage_package(destination, current_version, manifest["sha256"], "automatic")
    except UpdateError:
        raise
    except Exception as exc:
        raise UpdateError("UPDATE_DOWNLOAD_FAILED", "The update package could not be downloaded securely") from exc
    finally:
        destination.unlink(missing_ok=True)


def status(current_version: str) -> dict[str, Any]:
    config = update_settings()
    state = read_state()
    latest = state.get("latest") if isinstance(state.get("latest"), dict) else None
    if latest:
        latest = dict(latest)
        latest["available"] = newer(latest["version"], current_version)
        latest["skipped"] = config["skipped_version"] == latest["version"]
    staged = state.get("staged") if isinstance(state.get("staged"), dict) else None
    if staged and not Path(str(staged.get("extract_dir", ""))).is_dir():
        staged = None
    return {
        "current_version": current_version,
        "settings": config,
        "latest": latest,
        "staged": staged,
        "last_check": state.get("last_check"),
        "last_error": state.get("last_error", ""),
        "last_result": state.get("last_result"),
        "history": list(state.get("history", []))[-20:][::-1],
        "platform_supported": os.name == "nt",
    }


def clear_staged() -> None:
    state = read_state()
    staged = state.pop("staged", None) or {}
    write_state(state)
    root = Path(str(staged.get("extract_dir", ""))).parent
    if root.exists() and _update_dir() in root.parents:
        shutil.rmtree(root, ignore_errors=True)
