from __future__ import annotations
import hashlib,json,mimetypes,shutil,threading,time,uuid
from datetime import datetime,timezone,timedelta
from pathlib import Path,PurePosixPath
from . import database as db
from .filesystem import normalize_relative,safe_path
from .advanced import unique_path

TEXT_EXT={'.txt','.md','.csv','.json','.xml','.html','.css','.js','.ts','.py','.java','.c','.cpp','.cs','.go','.rs','.php','.rb','.sh','.log','.yaml','.yml','.ini'}
IMAGE_EXT={'.png','.jpg','.jpeg','.webp','.bmp','.tif','.tiff'}


def _json(value,default):
    try:return json.loads(value) if isinstance(value,str) else value
    except Exception:return default

def notify(user_id:int,kind:str,title:str,message:str='',action_url:str=''):
    nid=uuid.uuid4().hex
    db.execute('INSERT INTO notifications(id,user_id,kind,title,message,action_url,is_read,created_at) VALUES(?,?,?,?,?,?,0,?)',(nid,user_id,kind[:40],title[:160],message[:600],action_url[:500],db.now_iso()))
    return nid

def notifications(user_id:int,limit:int=100):
    items=[dict(x) for x in db.all('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT ?',(user_id,min(max(limit,1),300)))]
    return {'items':items,'unread':sum(1 for x in items if not x['is_read'])}

def mark_notifications(user_id:int,ids:list[str]|None=None,all_items:bool=False):
    if all_items:db.execute('UPDATE notifications SET is_read=1 WHERE user_id=?',(user_id,))
    elif ids:
        marks=','.join('?' for _ in ids);db.execute(f'UPDATE notifications SET is_read=1 WHERE user_id=? AND id IN ({marks})',(user_id,*ids))

def list_tags(user_id:int):
    return [dict(x) for x in db.all('SELECT t.*,COUNT(ft.relative_path) item_count FROM tags t LEFT JOIN file_tags ft ON ft.tag_id=t.id WHERE t.owner_id=? GROUP BY t.id ORDER BY t.name COLLATE NOCASE',(user_id,))]

def create_tag(user_id:int,name:str,color:str='#d7ff45'):
    name=name.strip()[:60]
    if not name:raise ValueError('Tag name is required')
    if not color.startswith('#') or len(color)!=7:color='#d7ff45'
    tid=uuid.uuid4().hex
    try:db.execute('INSERT INTO tags(id,owner_id,name,color,created_at) VALUES(?,?,?,?,?)',(tid,user_id,name,color,db.now_iso()))
    except Exception:
        row=db.one('SELECT id FROM tags WHERE owner_id=? AND name=? COLLATE NOCASE',(user_id,name))
        if not row:raise
        tid=row['id']
    return dict(db.one('SELECT * FROM tags WHERE id=?',(tid,)))

def delete_tag(user_id:int,tag_id:str):db.execute('DELETE FROM tags WHERE id=? AND owner_id=?',(tag_id,user_id))

def set_file_tags(user_id:int,drive_id:str,path:str,tag_ids:list[str]):
    path=normalize_relative(path);valid=[]
    if tag_ids:
        marks=','.join('?' for _ in tag_ids)
        valid=[x['id'] for x in db.all(f'SELECT id FROM tags WHERE owner_id=? AND id IN ({marks})',(user_id,*tag_ids))]
    with db.connection() as con:
        con.execute('DELETE FROM file_tags WHERE user_id=? AND drive_id=? AND relative_path=?',(user_id,drive_id,path))
        con.executemany('INSERT INTO file_tags(user_id,tag_id,drive_id,relative_path,created_at) VALUES(?,?,?,?,?)',[(user_id,t,drive_id,path,db.now_iso()) for t in valid])
    return file_tags(user_id,drive_id,path)

def file_tags(user_id:int,drive_id:str,path:str):
    return [dict(x) for x in db.all('SELECT t.id,t.name,t.color FROM tags t JOIN file_tags ft ON ft.tag_id=t.id WHERE ft.user_id=? AND ft.drive_id=? AND ft.relative_path=? ORDER BY t.name COLLATE NOCASE',(user_id,drive_id,normalize_relative(path)))]

def create_collection(user_id:int,name:str,criteria:dict):
    cid=uuid.uuid4().hex;db.execute('INSERT INTO smart_collections(id,owner_id,name,criteria,created_at) VALUES(?,?,?,?,?)',(cid,user_id,name.strip()[:100] or 'Untitled collection',json.dumps(criteria),db.now_iso()));return cid

def list_collections(user_id:int):
    rows=[]
    for row in db.all('SELECT * FROM smart_collections WHERE owner_id=? ORDER BY name COLLATE NOCASE',(user_id,)):
        item=dict(row);item['criteria']=_json(item['criteria'],{});rows.append(item)
    return rows

def delete_collection(user_id:int,cid:str):db.execute('DELETE FROM smart_collections WHERE id=? AND owner_id=?',(cid,user_id))

def collection_items(user_id:int,cid:str,drive_ids:list[str],limit:int=300):
    row=db.one('SELECT * FROM smart_collections WHERE id=? AND owner_id=?',(cid,user_id))
    if not row:return None
    return smart_query(user_id,_json(row['criteria'],{}),drive_ids,limit)

def smart_query(user_id:int,c:dict,drive_ids:list[str],limit:int=300):
    if not drive_ids:return []
    where=[f"m.drive_id IN ({','.join('?' for _ in drive_ids)})"];params=list(drive_ids)
    q=str(c.get('q','')).strip()
    if q:where.append('(m.name LIKE ? OR m.relative_path LIKE ? OR EXISTS(SELECT 1 FROM ocr_index o WHERE o.drive_id=m.drive_id AND o.relative_path=m.relative_path AND o.extracted_text LIKE ?))');params += [f'%{q}%',f'%{q}%',f'%{q}%']
    exts=c.get('extensions') or ([] if not c.get('extension') else [c['extension']])
    if isinstance(exts,str):exts=[x.strip() for x in exts.split(',') if x.strip()]
    exts=[x.lower() if str(x).startswith('.') else '.'+str(x).lower() for x in exts]
    if exts:where.append(f"m.extension IN ({','.join('?' for _ in exts)})");params+=exts
    if c.get('min_size') is not None:where.append('m.size_bytes>=?');params.append(int(c['min_size']))
    if c.get('max_size') is not None:where.append('m.size_bytes<=?');params.append(int(c['max_size']))
    if c.get('older_days'):
        cutoff=(datetime.now(timezone.utc)-timedelta(days=int(c['older_days']))).timestamp();where.append('CAST(m.modified_at AS REAL)<?');params.append(cutoff)
    if c.get('untagged'):where.append('NOT EXISTS(SELECT 1 FROM file_tags ft WHERE ft.user_id=? AND ft.drive_id=m.drive_id AND ft.relative_path=m.relative_path)');params.append(user_id)
    tag_ids=c.get('tag_ids') or []
    if tag_ids:
        where.append(f"EXISTS(SELECT 1 FROM file_tags ft WHERE ft.user_id=? AND ft.drive_id=m.drive_id AND ft.relative_path=m.relative_path AND ft.tag_id IN ({','.join('?' for _ in tag_ids)}))");params += [user_id,*tag_ids]
    typ=c.get('file_type')
    types={'folder':'m.is_dir=1','image':"m.mime_type LIKE 'image/%'",'video':"m.mime_type LIKE 'video/%'",'audio':"m.mime_type LIKE 'audio/%'",'pdf':"m.mime_type='application/pdf'",'document':"m.mime_type LIKE 'text/%' OR m.extension IN ('.pdf','.doc','.docx','.md','.rtf')"}
    if typ in types:where.append('('+types[typ]+')')
    sql='SELECT m.*,d.display_name drive_name,d.letter drive_letter FROM file_metadata m JOIN drives d ON d.id=m.drive_id WHERE '+' AND '.join(where)+' ORDER BY m.is_dir DESC,CAST(m.modified_at AS REAL) DESC LIMIT ?';params.append(min(max(limit,1),500))
    return [dict(x) for x in db.all(sql,params)]

def register_inbox(user_id:int,drive_id:str,path:str,source:str='upload'):
    path=normalize_relative(path);iid=uuid.uuid4().hex
    db.execute("INSERT INTO inbox_items(id,user_id,drive_id,relative_path,source,status,created_at) VALUES(?,?,?,?,?,'NEW',?) ON CONFLICT(user_id,drive_id,relative_path) DO UPDATE SET source=excluded.source,status='NEW',created_at=excluded.created_at",(iid,user_id,drive_id,path,source,db.now_iso()))
    notify(user_id,'arrival','New item received',PurePosixPath(path).name,f'/files?select={path}')
    return iid

def list_inbox(user_id:int,status:str='NEW'):
    return [dict(x) for x in db.all('SELECT i.*,m.name,m.size_bytes,m.mime_type,m.modified_at,d.display_name drive_name,d.letter drive_letter FROM inbox_items i LEFT JOIN file_metadata m ON m.drive_id=i.drive_id AND m.relative_path=i.relative_path LEFT JOIN drives d ON d.id=i.drive_id WHERE i.user_id=? AND (?="" OR i.status=?) ORDER BY i.created_at DESC',(user_id,status,status))]

def resolve_inbox(user_id:int,ids:list[str],status:str='ORGANIZED'):
    if not ids:return
    marks=','.join('?' for _ in ids);db.execute(f'UPDATE inbox_items SET status=?,resolved_at=? WHERE user_id=? AND id IN ({marks})',(status,db.now_iso(),user_id,*ids))

def _extract_text(path:Path,max_chars:int=250000):
    ext=path.suffix.lower()
    if ext in TEXT_EXT:return path.read_text('utf-8',errors='ignore')[:max_chars], 'text'
    if ext=='.pdf':
        import fitz
        doc=fitz.open(path)
        try:return '\n'.join(page.get_text('text') for page in doc)[:max_chars], 'pdf'
        finally:doc.close()
    if ext in IMAGE_EXT:
        try:
            import pytesseract
            from PIL import Image,ImageOps
            with Image.open(path) as im:return pytesseract.image_to_string(ImageOps.exif_transpose(im))[:max_chars], 'ocr'
        except Exception as e:raise RuntimeError('Image OCR requires the Tesseract desktop engine') from e
    raise ValueError('This file type is not supported for content extraction')

def index_content(drive:dict,path:str):
    rel,p=safe_path(drive,path,True,False);started=time.time()
    try:
        text,engine=_extract_text(p);status='READY';error=''
    except Exception as e:text='';engine='';status='UNAVAILABLE' if isinstance(e,(ImportError,RuntimeError)) else 'SKIPPED';error=str(e)[:500]
    db.execute('INSERT INTO ocr_index(drive_id,relative_path,extracted_text,status,engine,error,updated_at,duration_ms) VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(drive_id,relative_path) DO UPDATE SET extracted_text=excluded.extracted_text,status=excluded.status,engine=excluded.engine,error=excluded.error,updated_at=excluded.updated_at,duration_ms=excluded.duration_ms',(drive['id'],rel,text,status,engine,error,db.now_iso(),round((time.time()-started)*1000)))
    return {'drive_id':drive['id'],'path':rel,'status':status,'characters':len(text),'engine':engine,'error':error}

def content_search(query:str,drive_ids:list[str],limit:int=100):
    if not query.strip() or not drive_ids:return []
    marks=','.join('?' for _ in drive_ids);needle=f'%{query.strip()}%'
    sql=f'''SELECT o.drive_id,o.relative_path,o.status,m.name,m.size_bytes,m.mime_type,m.modified_at,d.display_name drive_name,
    substr(o.extracted_text,max(1,instr(lower(o.extracted_text),lower(?))-80),240) excerpt
    FROM ocr_index o JOIN file_metadata m ON m.drive_id=o.drive_id AND m.relative_path=o.relative_path JOIN drives d ON d.id=o.drive_id
    WHERE o.drive_id IN ({marks}) AND o.status='READY' AND o.extracted_text LIKE ? LIMIT ?'''
    return [dict(x) for x in db.all(sql,(query,*drive_ids,needle,min(max(limit,1),300)))]

def hash_file(drive:dict,path:str):
    rel,p=safe_path(drive,path,True,False);st=p.stat();h=hashlib.sha256()
    with p.open('rb') as f:
        for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
    digest=h.hexdigest();db.execute('INSERT INTO file_hashes(drive_id,relative_path,size_bytes,modified_at,sha256,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(drive_id,relative_path) DO UPDATE SET size_bytes=excluded.size_bytes,modified_at=excluded.modified_at,sha256=excluded.sha256,updated_at=excluded.updated_at',(drive['id'],rel,st.st_size,str(st.st_mtime),digest,db.now_iso()));return digest

def scan_drive_intelligence(drive:dict,max_files:int=500,content:bool=True):
    rows=db.all('SELECT relative_path,size_bytes,modified_at,extension FROM file_metadata WHERE drive_id=? AND is_dir=0 ORDER BY size_bytes ASC LIMIT ?',(drive['id'],max_files));hashed=extracted=0;errors=[]
    for row in rows:
        try:
            old=db.one('SELECT modified_at FROM file_hashes WHERE drive_id=? AND relative_path=?',(drive['id'],row['relative_path']))
            if not old or str(old['modified_at'])!=str(row['modified_at']):hash_file(drive,row['relative_path']);hashed+=1
            if content and row['extension'].lower() in TEXT_EXT|IMAGE_EXT|{'.pdf'}:
                prev=db.one('SELECT updated_at FROM ocr_index WHERE drive_id=? AND relative_path=?',(drive['id'],row['relative_path']))
                if not prev:index_content(drive,row['relative_path']);extracted+=1
        except Exception as e:errors.append({'path':row['relative_path'],'error':str(e)[:200]})
    record_storage_sample(drive['id']);return {'scanned':len(rows),'hashed':hashed,'content_indexed':extracted,'errors':errors[:20]}

def duplicate_groups(drive_ids:list[str],limit:int=100):
    if not drive_ids:return []
    marks=','.join('?' for _ in drive_ids);groups=[]
    rows=db.all(f'SELECT sha256,COUNT(*) copies,MAX(size_bytes) each_size,SUM(size_bytes)-MAX(size_bytes) reclaimable FROM file_hashes WHERE drive_id IN ({marks}) GROUP BY sha256 HAVING COUNT(*)>1 ORDER BY reclaimable DESC LIMIT ?',(*drive_ids,min(max(limit,1),300)))
    for row in rows:
        members=[dict(x) for x in db.all(f'SELECT h.drive_id,h.relative_path,h.size_bytes,d.display_name drive_name FROM file_hashes h JOIN drives d ON d.id=h.drive_id WHERE h.sha256=? AND h.drive_id IN ({marks}) ORDER BY h.relative_path',(row['sha256'],*drive_ids))]
        groups.append({'sha256':row['sha256'],'copies':row['copies'],'size_bytes':row['each_size'],'reclaimable':row['reclaimable'],'items':members})
    return groups

def record_storage_sample(drive_id:str):
    row=db.one('SELECT COALESCE(SUM(size_bytes),0) bytes,COUNT(CASE WHEN is_dir=0 THEN 1 END) files FROM file_metadata WHERE drive_id=?',(drive_id,));drive=db.one('SELECT total_bytes,free_bytes FROM drives WHERE id=?',(drive_id,))
    if drive:db.execute('INSERT INTO storage_samples(drive_id,total_bytes,free_bytes,cloud_bytes,file_count,created_at) VALUES(?,?,?,?,?,?)',(drive_id,drive['total_bytes'],drive['free_bytes'],row['bytes'],row['files'],db.now_iso()))

def storage_intelligence(drive_ids:list[str]):
    if not drive_ids:return {'total':0,'files':0,'types':[],'largest':[],'folders':[],'duplicates':{'groups':0,'reclaimable':0},'versions':0,'trash':0,'growth':[]}
    marks=','.join('?' for _ in drive_ids)
    summary=dict(db.one(f'SELECT COALESCE(SUM(size_bytes),0) total,SUM(CASE WHEN is_dir=0 THEN 1 ELSE 0 END) files,SUM(CASE WHEN is_dir=1 THEN 1 ELSE 0 END) folders FROM file_metadata WHERE drive_id IN ({marks})',drive_ids))
    types=[dict(x) for x in db.all(f"SELECT CASE WHEN extension='' THEN '(none)' ELSE extension END extension,COUNT(*) count,SUM(size_bytes) bytes FROM file_metadata WHERE drive_id IN ({marks}) AND is_dir=0 GROUP BY extension ORDER BY bytes DESC LIMIT 12",drive_ids)]
    largest=[dict(x) for x in db.all(f'SELECT m.drive_id,m.relative_path,m.name,m.size_bytes,d.display_name drive_name FROM file_metadata m JOIN drives d ON d.id=m.drive_id WHERE m.drive_id IN ({marks}) AND m.is_dir=0 ORDER BY m.size_bytes DESC LIMIT 20',drive_ids)]
    dups=db.one(f'SELECT COUNT(*) groups_count,COALESCE(SUM(reclaimable),0) reclaimable FROM (SELECT SUM(size_bytes)-MAX(size_bytes) reclaimable FROM file_hashes WHERE drive_id IN ({marks}) GROUP BY sha256 HAVING COUNT(*)>1)',drive_ids)
    versions=db.one(f'SELECT COALESCE(SUM(size_bytes),0) n FROM file_versions WHERE drive_id IN ({marks})',drive_ids)['n'];trash=db.one(f'SELECT COALESCE(SUM(size_bytes),0) n FROM trash WHERE drive_id IN ({marks})',drive_ids)['n']
    growth=[dict(x) for x in db.all(f'SELECT drive_id,cloud_bytes,file_count,created_at FROM storage_samples WHERE drive_id IN ({marks}) ORDER BY created_at DESC LIMIT 60',drive_ids)]
    return {**summary,'types':types,'largest':largest,'duplicates':{'groups':dups['groups_count'],'reclaimable':dups['reclaimable']},'versions':versions,'trash':trash,'growth':growth}

def list_rules(user_id:int):
    rows=[]
    for x in db.all('SELECT * FROM automation_rules WHERE owner_id=? ORDER BY created_at DESC',(user_id,)):
        r=dict(x);r['conditions']=_json(r['conditions'],{});r['actions']=_json(r['actions'],[]);rows.append(r)
    return rows

def create_rule(user_id:int,name:str,trigger:str,conditions:dict,actions:list[dict],enabled:bool=True,dry_run:bool=True):
    rid=uuid.uuid4().hex;db.execute('INSERT INTO automation_rules(id,owner_id,name,trigger_name,conditions,actions,enabled,dry_run,created_at) VALUES(?,?,?,?,?,?,?,?,?)',(rid,user_id,name.strip()[:100] or 'Untitled rule',trigger[:30],json.dumps(conditions),json.dumps(actions),int(enabled),int(dry_run),db.now_iso()));return rid

def delete_rule(user_id:int,rid:str):db.execute('DELETE FROM automation_rules WHERE id=? AND owner_id=?',(rid,user_id))

def _matches(path:str,size:int,conditions:dict):
    p=PurePosixPath(path);ext=p.suffix.lower()
    if conditions.get('extension') and ext!=(conditions['extension'] if str(conditions['extension']).startswith('.') else '.'+str(conditions['extension'])).lower():return False
    if conditions.get('name_contains') and str(conditions['name_contains']).lower() not in p.name.lower():return False
    if conditions.get('min_size') and size<int(conditions['min_size']):return False
    if conditions.get('max_size') and size>int(conditions['max_size']):return False
    return True

def run_rule(user_id:int,rule_id:str,drive:dict,path:str,execute:bool=False):
    row=db.one('SELECT * FROM automation_rules WHERE id=? AND owner_id=?',(rule_id,user_id))
    if not row:return {'matched':False,'actions':[],'error':'Rule not found'}
    rel,p=safe_path(drive,path,True,False);conditions=_json(row['conditions'],{});actions=_json(row['actions'],[])
    if not _matches(rel,p.stat().st_size,conditions):return {'matched':False,'actions':[]}
    planned=[];current=rel;should_execute=execute and not bool(row['dry_run'])
    for action in actions:
        kind=action.get('type')
        if kind=='tag':
            tag=create_tag(user_id,str(action.get('name','Automated')),str(action.get('color','#d7ff45')));planned.append({'type':'tag','tag':tag['name']})
            if should_execute:
                existing=[x['id'] for x in file_tags(user_id,drive['id'],current)];set_file_tags(user_id,drive['id'],current,list(dict.fromkeys(existing+[tag['id']])))
        elif kind in {'move','copy'}:
            folder=normalize_relative(str(action.get('folder','')));_,dst_dir=safe_path(drive,folder,True);target_rel=unique_path(drive,folder,PurePosixPath(current).name);_,dst=safe_path(drive,target_rel,False);planned.append({'type':kind,'destination':target_rel})
            if should_execute:
                dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dst) if kind=='copy' else shutil.move(p,dst)
                if kind=='move':current=target_rel;p=dst
    db.execute('UPDATE automation_rules SET last_run=?,last_result=? WHERE id=?',(db.now_iso(),json.dumps({'matched':True,'executed':should_execute,'actions':planned}),rule_id));return {'matched':True,'executed':should_execute,'path':current,'actions':planned}

def process_arrival(user_id:int,drive:dict,path:str,source:str):
    register_inbox(user_id,drive['id'],path,source)
    try:hash_file(drive,path)
    except Exception:pass
    try:
        if Path(path).suffix.lower() in TEXT_EXT|IMAGE_EXT|{'.pdf'}:index_content(drive,path)
    except Exception:pass
    current=path
    for rule in db.all("SELECT id FROM automation_rules WHERE owner_id=? AND enabled=1 AND trigger_name IN ('arrival',?)",(user_id,source)):
        try:
            result=run_rule(user_id,rule['id'],drive,current,True)
            moved=result.get('path',current)
            if moved!=current:
                db.execute('UPDATE inbox_items SET relative_path=? WHERE user_id=? AND drive_id=? AND relative_path=?',(moved,user_id,drive['id'],current))
                current=moved
        except Exception as e:notify(user_id,'rule','Automation rule failed',str(e),'/automation')

def workspace_summary(user_id:int,drive_ids:list[str]):
    tags=list_tags(user_id);collections=list_collections(user_id);inbox=db.one("SELECT COUNT(*) n FROM inbox_items WHERE user_id=? AND status='NEW'",(user_id,))['n'];notes=notifications(user_id,20);rules=list_rules(user_id);storage=storage_intelligence(drive_ids)
    return {'tags':tags,'collections':collections,'inbox_count':inbox,'unread_notifications':notes['unread'],'rules':rules,'storage':storage}
