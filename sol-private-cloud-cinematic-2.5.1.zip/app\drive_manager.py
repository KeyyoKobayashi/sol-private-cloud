import hashlib,json,os,platform,shutil,subprocess
from pathlib import Path
from . import database as db
DRIVE_TYPES={0:'Unknown',1:'No root',2:'Removable',3:'Local disk',4:'Network',5:'Optical',6:'RAM disk'}
def drive_id(letter):return hashlib.sha256(letter.upper().encode()).hexdigest()[:16]
def detect_drives():
 if os.name=='nt':
  script='Get-CimInstance Win32_LogicalDisk | Select-Object DeviceID,VolumeName,Size,FreeSpace,DriveType | ConvertTo-Json -Compress';flags=getattr(subprocess,'CREATE_NO_WINDOW',0);r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],capture_output=True,text=True,timeout=20,creationflags=flags)
  if r.returncode:raise RuntimeError(r.stderr.strip() or 'PowerShell drive detection failed')
  if not r.stdout.strip():return []
  items=json.loads(r.stdout);items=items if isinstance(items,list) else [items];out=[]
  for x in items:
   letter=str(x.get('DeviceID') or '').upper()
   if not letter:continue
   total=int(x.get('Size') or 0);free=int(x.get('FreeSpace') or 0);out.append({'id':drive_id(letter),'letter':letter,'label':x.get('VolumeName') or letter,'total_bytes':total,'free_bytes':free,'used_bytes':max(0,total-free),'drive_type':DRIVE_TYPES.get(int(x.get('DriveType') or 0),'Unknown'),'online':True})
  return out
 usage=shutil.disk_usage('/');return [{'id':drive_id('POSIX:/'),'letter':'POSIX:/','label':platform.system()+' root','total_bytes':usage.total,'free_bytes':usage.free,'used_bytes':usage.used,'drive_type':'Local disk','online':True}]
def sync_detected():
 found=detect_drives();now=db.now_iso()
 with db.connection() as con:
  con.execute('UPDATE drives SET online=0')
  for d in found:con.execute('''INSERT INTO drives(id,letter,detected_label,display_name,total_bytes,free_bytes,drive_type,online,enabled,updated_at,last_seen) VALUES(?,?,?,?,?,?,?,?,0,?,?) ON CONFLICT(id) DO UPDATE SET letter=excluded.letter,detected_label=excluded.detected_label,total_bytes=excluded.total_bytes,free_bytes=excluded.free_bytes,drive_type=excluded.drive_type,online=1,last_seen=excluded.last_seen''',(d['id'],d['letter'],d['label'],d['label'],d['total_bytes'],d['free_bytes'],d['drive_type'],1,now,now))
 return list_drives()
def rowdict(row):
 d=dict(row);d['used_bytes']=max(0,d['total_bytes']-d['free_bytes']);d['usage_percent']=round(d['used_bytes']*100/d['total_bytes'],1) if d['total_bytes'] else 0
 for k in ('enabled','online','read_only','allow_upload','allow_download','allow_delete','allow_rename','allow_move','allow_copy','allow_share','show_hidden','is_default'):d[k]=bool(d[k])
 for k in ('allowed_extensions','blocked_extensions'):
  try:d[k]=json.loads(d[k] or '[]')
  except:d[k]=[]
 return d
def list_drives(enabled_only=False):return [rowdict(x) for x in db.all('SELECT * FROM drives'+(' WHERE enabled=1' if enabled_only else '')+' ORDER BY is_default DESC,priority,letter')]
def get_drive(value,require_enabled=True):
 row=db.one('SELECT * FROM drives WHERE id=?',(value,))
 if not row:raise FileNotFoundError('Drive is not configured')
 d=rowdict(row)
 if require_enabled and not d['enabled']:raise PermissionError('Drive is disabled')
 if not d['online']:raise OSError('Drive is offline or disconnected')
 if require_enabled and (not d['root_path'] or not Path(d['root_path']).exists()):raise OSError('Configured cloud root is unavailable')
 return d
def validate_safe_root(letter,root_path,create=False):
 if not root_path or '\0' in root_path:raise ValueError('A safe root directory is required')
 root=Path(root_path).expanduser();absolute=str(root.resolve(strict=False))
 if os.name=='nt':
  prefix=letter.upper().rstrip('\\/')+'\\'
  if not absolute.upper().startswith(prefix):raise ValueError(f'Root must be located on {letter}')
  if os.path.normcase(os.path.normpath(absolute))==os.path.normcase(os.path.normpath(prefix)):raise ValueError('An entire drive cannot be exposed; choose a dedicated subfolder')
 elif absolute=='/':raise ValueError('An entire system root cannot be exposed')
 if create:Path(absolute).mkdir(parents=True,exist_ok=True)
 if not Path(absolute).is_dir():raise ValueError('Safe root does not exist or is not a directory')
 return str(Path(absolute).resolve())
def update_drive(value,data):
 current=get_drive(value,False);allowed={'display_name','icon','color','quota_bytes','read_only','allow_upload','allow_download','allow_delete','allow_rename','allow_move','allow_copy','allow_share','max_upload_bytes','show_hidden','priority','is_default'};updates={k:v for k,v in data.items() if k in allowed}
 if 'root_path' in data:updates['root_path']=validate_safe_root(current['letter'],str(data['root_path']),bool(data.get('create_root')))
 if 'enabled' in data:
  if data['enabled'] and not (updates.get('root_path') or current.get('root_path')):raise ValueError('Configure a safe root before enabling this drive')
  updates['enabled']=int(bool(data['enabled']))
 for k in ('allowed_extensions','blocked_extensions'):
  if k in data:updates[k]=json.dumps(sorted({(str(x) if str(x).startswith('.') else '.'+str(x)).lower() for x in data[k]}))
 for k in {'read_only','allow_upload','allow_download','allow_delete','allow_rename','allow_move','allow_copy','allow_share','show_hidden','is_default'}:
  if k in updates:updates[k]=int(bool(updates[k]))
 if updates:
  if updates.get('is_default'):db.execute('UPDATE drives SET is_default=0')
  updates['updated_at']=db.now_iso();db.execute('UPDATE drives SET '+','.join(f'{k}=?' for k in updates)+' WHERE id=?',(*updates.values(),value))
 return get_drive(value,False)
