from __future__ import annotations
import os,shutil,time,uuid,threading
from datetime import datetime,timezone
from pathlib import Path
from . import database as db
from .filesystem import safe_path,_is_reparse
SYNC_IGNORE={'.sol-cloud','.sol-trash','.sol-sync-trash'}
_pair_locks:dict[str,threading.Lock]={}
def _scan(root:Path):
 out={}
 for base,dirs,files in os.walk(root,followlinks=False):
  dirs[:]=[d for d in dirs if d not in SYNC_IGNORE and not _is_reparse(Path(base)/d)]
  for name in files:
   p=Path(base)/name
   if _is_reparse(p):continue
   try:r=p.relative_to(root).as_posix();s=p.stat();out[r]=(s.st_size,round(s.st_mtime,3),p)
   except OSError:pass
 return out
def _copy(src:Path,dst:Path):
 dst.parent.mkdir(parents=True,exist_ok=True);tmp=dst.with_name('.'+dst.name+'.sync-'+uuid.uuid4().hex);shutil.copy2(src,tmp);os.replace(tmp,dst)
def _trash(path:Path,root:Path):
 rel=path.relative_to(root);dst=root/'.sol-sync-trash'/str(int(time.time()))/rel;dst.parent.mkdir(parents=True,exist_ok=True);os.replace(path,dst)
def run_sync(pair:dict,drive:dict):
 lock=_pair_locks.setdefault(pair['id'],threading.Lock())
 if not lock.acquire(False):return ['already-running']
 try:
  local=Path(pair['local_path']).resolve();_,cloud=safe_path(drive,pair['cloud_path'],True);local.mkdir(parents=True,exist_ok=True);cloud.mkdir(parents=True,exist_ok=True);a,b=_scan(local),_scan(cloud);actions=[]
  state={r['relative_path']:dict(r) for r in db.all('SELECT * FROM sync_state WHERE pair_id=?',(pair['id'],))}
  for rel in sorted(set(a)|set(b)|set(state)):
   old=state.get(rel,{});ls=a.get(rel);cs=b.get(rel);lp=local/rel;cp=cloud/rel;ol=bool(old.get('local_exists'));oc=bool(old.get('cloud_exists'));lsig=ls[:2] if ls else None;csig=cs[:2] if cs else None;oldl=(old.get('local_size'),round(old.get('local_mtime') or 0,3)) if ol else None;oldc=(old.get('cloud_size'),round(old.get('cloud_mtime') or 0,3)) if oc else None;lc=lsig!=oldl;cc=csig!=oldc
   try:
    if ls and not cs:
     if oc and ol and not lc:_trash(lp,local);actions.append('deleted-local:'+rel)
     else:_copy(lp,cp);actions.append('uploaded:'+rel)
    elif cs and not ls:
     if ol and oc and not cc:_trash(cp,cloud);actions.append('deleted-cloud:'+rel)
     else:_copy(cp,lp);actions.append('downloaded:'+rel)
    elif ls and cs and lsig!=csig:
     if lc and cc:
      if ls[1]>=cs[1]:_copy(cp,cp.with_name(cp.stem+f'.sync-conflict-{int(time.time())}'+cp.suffix));_copy(lp,cp);actions.append('conflict-local-won:'+rel)
      else:_copy(lp,lp.with_name(lp.stem+f'.sync-conflict-{int(time.time())}'+lp.suffix));_copy(cp,lp);actions.append('conflict-cloud-won:'+rel)
     elif lc:_copy(lp,cp);actions.append('uploaded:'+rel)
     elif cc:_copy(cp,lp);actions.append('downloaded:'+rel)
   except OSError as e:actions.append('error:'+rel+':'+str(e))
  a2,b2=_scan(local),_scan(cloud)
  with db.connection() as con:
   con.execute('DELETE FROM sync_state WHERE pair_id=?',(pair['id'],))
   for rel in set(a2)|set(b2):
    ls=a2.get(rel);cs=b2.get(rel);con.execute('INSERT INTO sync_state(pair_id,relative_path,local_size,local_mtime,cloud_size,cloud_mtime,local_exists,cloud_exists) VALUES(?,?,?,?,?,?,?,?)',(pair['id'],rel,ls[0] if ls else None,ls[1] if ls else None,cs[0] if cs else None,cs[1] if cs else None,int(bool(ls)),int(bool(cs))))
  db.execute('UPDATE sync_pairs SET last_run=?,last_result=? WHERE id=?',(db.now_iso(),';'.join(actions[-100:]) or 'no-changes',pair['id']));return actions
 finally:lock.release()
def run_due_syncs(get_drive):
 now=time.time()
 for row in db.all('SELECT * FROM sync_pairs WHERE enabled=1'):
  pair=dict(row)
  if pair.get('last_run'):
   try:
    if now-datetime.fromisoformat(pair['last_run']).timestamp()<pair['interval_seconds']:continue
   except Exception:pass
  try:run_sync(pair,get_drive(pair['drive_id']))
  except Exception as e:db.execute('UPDATE sync_pairs SET last_run=?,last_result=? WHERE id=?',(db.now_iso(),'error:'+str(e),pair['id']))
