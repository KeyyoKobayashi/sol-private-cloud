import mimetypes,os,re,shutil,stat,urllib.parse,uuid,zipfile
from pathlib import Path,PurePosixPath
from . import database as db
RESERVED={'CON','PRN','AUX','NUL',*(f'COM{i}' for i in range(1,10)),*(f'LPT{i}' for i in range(1,10))}
def normalize_relative(value):
 value=str(value or '')
 if '\0' in value:raise ValueError('Null bytes are forbidden')
 for _ in range(4):
  decoded=urllib.parse.unquote(value)
  if decoded==value:break
  value=decoded
 value=value.replace('\\','/')
 if value.startswith('/') or re.match(r'^[A-Za-z]:',value):raise ValueError('Absolute paths are forbidden')
 parts=[]
 for p in value.split('/'):
  if p in ('','.'):continue
  if p=='..':raise ValueError('Path traversal is forbidden')
  if len(p)>255 or p.rstrip(' .')!=p or p.split('.',1)[0].upper() in RESERVED:raise ValueError('Invalid path component')
  parts.append(p)
 return '/'.join(parts)
def validate_name(name):
 name=str(name).strip()
 if not name or name in ('.','..') or any(c in name for c in '<>:"/\\|?*\0') or name.rstrip(' .')!=name or len(name)>255 or name.split('.',1)[0].upper() in RESERVED:raise ValueError('Invalid Windows filename')
 return name
def _is_reparse(p):
 try:return p.is_symlink() or bool(getattr(p.lstat(),'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_REPARSE_POINT',0x400))
 except:return False
def safe_path(drive,relative,exists=None,allow_root=True):
 rel=normalize_relative(relative)
 if rel and PurePosixPath(rel).parts[0] in {'.sol-trash','.sol-cloud','.sol-sync-trash'}:raise PermissionError('Application-managed storage is not accessible')
 root=Path(drive['root_path']).resolve(strict=True)
 if not rel and not allow_root:raise ValueError('Cloud root cannot be modified')
 candidate=root.joinpath(*PurePosixPath(rel).parts);current=root
 for part in PurePosixPath(rel).parts:
  current=current/part
  if current.exists() and _is_reparse(current):raise PermissionError('Reparse points and symbolic links are not accessible')
 resolved=candidate.resolve(strict=True) if candidate.exists() else candidate.parent.resolve(strict=True)/candidate.name
 try:resolved.relative_to(root)
 except:raise PermissionError('Path escapes the configured cloud root')
 if exists is True and not resolved.exists():raise FileNotFoundError('File or folder not found')
 if exists is False and resolved.exists():raise FileExistsError('An item with this name already exists')
 return rel,resolved
def _hidden(p):
 try:return p.name.startswith('.') or bool(getattr(p.stat(),'st_file_attributes',0)&getattr(stat,'FILE_ATTRIBUTE_HIDDEN',2))
 except:return False
def describe(drive,rel,p):
 st=p.stat();is_dir=p.is_dir();mime=None if is_dir else mimetypes.guess_type(p.name)[0] or 'application/octet-stream';return {'drive_id':drive['id'],'path':rel,'name':p.name or drive['display_name'],'is_dir':is_dir,'type':'folder' if is_dir else 'file','size':0 if is_dir else st.st_size,'modified':st.st_mtime,'created':st.st_ctime,'extension':'' if is_dir else p.suffix.lower(),'mime':mime,'favorite':False}
def list_folder(drive,relative,sort_by='name',direction='asc',offset=0,limit=200):
 rel,folder=safe_path(drive,relative,True)
 if not folder.is_dir():raise NotADirectoryError('Path is not a folder')
 items=[]
 for e in os.scandir(folder):
  p=Path(e.path)
  if _is_reparse(p) or (not drive['show_hidden'] and _hidden(p)) or (not rel and e.name in {'.sol-trash','.sol-cloud','.sol-sync-trash'}):continue
  try:items.append(describe(drive,normalize_relative(f'{rel}/{e.name}'),p))
  except OSError:pass
 key={'name':lambda x:x['name'].casefold(),'size':lambda x:x['size'],'type':lambda x:(x['extension'],x['name'].casefold()),'modified':lambda x:x['modified']}.get(sort_by,lambda x:x['name'].casefold());items.sort(key=lambda x:(not x['is_dir'],key(x)),reverse=direction=='desc');return {'path':rel,'items':items[offset:offset+limit],'total':len(items),'offset':offset,'limit':limit}
def ensure_policy(drive,name,size=0,content_head=b''):
 ext=Path(name).suffix.lower();allowed=set(drive['allowed_extensions']);blocked=set(drive['blocked_extensions'])
 if ext in blocked:raise PermissionError(f'Files of type {ext} are blocked')
 if allowed and ext not in allowed:raise PermissionError(f'Files of type {ext or "(none)"} are not allowed')
 if drive['max_upload_bytes'] and size>drive['max_upload_bytes']:raise ValueError('File exceeds this drive upload limit')
 if content_head.startswith((b'MZ',b'\x7fELF')):raise PermissionError('Executable binary content is blocked')
def create_folder(drive,parent,name):
 name=validate_name(name);pr,_=safe_path(drive,parent,True);rel=normalize_relative('/'.join(x for x in (pr,name) if x));_,target=safe_path(drive,rel,False);target.mkdir();return describe(drive,rel,target)
def rename(drive,relative,new_name):
 rel,src=safe_path(drive,relative,True,False);new_name=validate_name(new_name);parent=str(PurePosixPath(rel).parent);parent='' if parent=='.' else parent;new_rel=normalize_relative('/'.join(x for x in (parent,new_name) if x));_,dst=safe_path(drive,new_rel,False);src.rename(dst);return describe(drive,new_rel,dst)
def move_or_copy(source_drive,paths,dest_drive,destination,copy_items):
 _,dest=safe_path(dest_drive,destination,True)
 if not dest.is_dir():raise NotADirectoryError('Destination is not a folder')
 out=[]
 for value in paths:
  rel,src=safe_path(source_drive,value,True,False);dst=dest/src.name
  if dst.exists():raise FileExistsError(f'{src.name} already exists at destination')
  if copy_items:shutil.copytree(src,dst) if src.is_dir() else shutil.copy2(src,dst)
  else:shutil.move(str(src),str(dst))
  new_rel=normalize_relative('/'.join(x for x in (destination,src.name) if x));out.append(describe(dest_drive,new_rel,dst))
 return out
def directory_size(p,limit_files=250000):
 size=files=folders=0
 for root,dirs,names in os.walk(p,followlinks=False):
  dirs[:]=[d for d in dirs if not _is_reparse(Path(root)/d) and d not in {'.sol-trash','.sol-cloud','.sol-sync-trash'}];folders+=len(dirs)
  for n in names:
   if files>=limit_files:return size,files,folders
   try:size+=(Path(root)/n).stat().st_size;files+=1
   except:pass
 return size,files,folders
def trash_items(drive,paths,user_id):
 trash=Path(drive['root_path'])/'.sol-trash';trash.mkdir(exist_ok=True);ids=[]
 for value in paths:
  rel,src=safe_path(drive,value,True,False);tag=uuid.uuid4().hex+'_'+src.name;dst=trash/tag;size=directory_size(src)[0] if src.is_dir() else src.stat().st_size;shutil.move(str(src),str(dst));ids.append(db.execute('INSERT INTO trash(drive_id,original_path,trash_path,item_name,deleted_by,deleted_at,size_bytes) VALUES(?,?,?,?,?,?,?)',(drive['id'],rel,tag,src.name,user_id,db.now_iso(),size)))
 return ids
def make_zip(drive,paths,output):
 with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,allowZip64=True) as z:
  for value in paths:
   rel,src=safe_path(drive,value,True,False);base=src.name
   if src.is_file():z.write(src,base)
   else:
    for root,dirs,files in os.walk(src,followlinks=False):
     dirs[:]=[d for d in dirs if not _is_reparse(Path(root)/d) and d not in {'.sol-trash','.sol-cloud','.sol-sync-trash'}]
     for name in files:
      f=Path(root)/name
      if not _is_reparse(f):z.write(f,str(Path(base)/f.relative_to(src)))
def sniff_head(path,n=4096):
 with path.open('rb') as f:return f.read(n)
