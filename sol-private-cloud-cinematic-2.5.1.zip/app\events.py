class EventHub:
 def __init__(self):self.clients=set()
 async def connect(self,ws):await ws.accept();self.clients.add(ws)
 def disconnect(self,ws):self.clients.discard(ws)
 async def broadcast(self,event,data):
  dead=[]
  for ws in list(self.clients):
   try:await ws.send_json({'event':event,'data':data})
   except:dead.append(ws)
  for ws in dead:self.clients.discard(ws)
hub=EventHub()
