@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Sol Private Cloud

if not exist .venv\Scripts\python.exe (
  echo The virtual environment is missing. Running installer...
  call install.bat
  if not exist .venv\Scripts\python.exe (
    echo Installation did not complete successfully.
    pause
    exit /b 1
  )
)

if not exist .env copy .env.example .env >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_cloud.ps1"
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" pause
exit /b %EXIT_CODE%
