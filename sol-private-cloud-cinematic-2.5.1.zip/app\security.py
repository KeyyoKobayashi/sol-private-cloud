import base64,hashlib,hmac,json,os,secrets
from datetime import datetime,timezone,timedelta
from .config import settings
PBKDF2_ROUNDS=600000
ALL_PERMISSIONS={'VIEW','UPLOAD','DOWNLOAD','DELETE','RENAME','MOVE','COPY','CREATE_FOLDER','SHARE','FAVORITE','PREVIEW'}
ROLE_DEFAULTS={'ADMIN':set(ALL_PERMISSIONS),'USER':set(ALL_PERMISSIONS),'READ_ONLY':{'VIEW','DOWNLOAD','FAVORITE','PREVIEW'}}
def hash_password(password):
 if len(password)<12:raise ValueError('Password must contain at least 12 characters')
 salt=os.urandom(16);digest=hashlib.pbkdf2_hmac('sha256',password.encode(),salt,PBKDF2_ROUNDS)
 return f"pbkdf2_sha256${PBKDF2_ROUNDS}${base64.urlsafe_b64encode(salt).decode()}${base64.urlsafe_b64encode(digest).decode()}"
def verify_password(password,encoded):
 try:
  _,rounds,salt,digest=encoded.split('$',3);actual=hashlib.pbkdf2_hmac('sha256',password.encode(),base64.urlsafe_b64decode(salt),int(rounds));return hmac.compare_digest(actual,base64.urlsafe_b64decode(digest))
 except:return False
def random_token(n=32):return secrets.token_urlsafe(n)
def token_hash(token):return hashlib.sha256(token.encode()).hexdigest()
def utcnow():return datetime.now(timezone.utc)
def iso_after(hours):return (utcnow()+timedelta(hours=hours)).isoformat()
def sign_payload(payload):
 raw=base64.urlsafe_b64encode(json.dumps(payload,separators=(',',':')).encode()).decode().rstrip('=');sig=hmac.new(settings.session_secret.encode(),raw.encode(),hashlib.sha256).hexdigest();return raw+'.'+sig
def verify_signed(token):
 try:
  raw,sig=token.rsplit('.',1);expected=hmac.new(settings.session_secret.encode(),raw.encode(),hashlib.sha256).hexdigest()
  if not hmac.compare_digest(sig,expected):return None
  data=json.loads(base64.urlsafe_b64decode(raw+'='*(-len(raw)%4)));return data if data.get('exp',0)>=utcnow().timestamp() else None
 except:return None
def validate_username(value):
 value=value.strip()
 if not 3<=len(value)<=40 or not all(c.isalnum() or c in '._-' for c in value):raise ValueError('Username must be 3–40 letters, numbers, dots, dashes, or underscores')
 return value
