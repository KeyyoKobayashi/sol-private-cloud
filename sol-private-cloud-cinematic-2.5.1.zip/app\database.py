import sqlite3,json
from contextlib import contextmanager
from datetime import datetime,timezone
from .config import settings
SCHEMA='''
PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE COLLATE NOCASE NOT NULL,display_name TEXT NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL,last_login TEXT);
CREATE TABLE IF NOT EXISTS sessions(id_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,csrf_hash TEXT NOT NULL,created_at TEXT NOT NULL,expires_at TEXT NOT NULL,ip TEXT,user_agent TEXT);
CREATE TABLE IF NOT EXISTS login_attempts(ip TEXT PRIMARY KEY,failures INTEGER NOT NULL,window_start TEXT NOT NULL,blocked_until TEXT);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS drives(id TEXT PRIMARY KEY,letter TEXT UNIQUE NOT NULL,detected_label TEXT,display_name TEXT,root_path TEXT,total_bytes INTEGER DEFAULT 0,free_bytes INTEGER DEFAULT 0,drive_type TEXT,online INTEGER DEFAULT 0,enabled INTEGER DEFAULT 0,icon TEXT DEFAULT 'drive',color TEXT DEFAULT '#3478f6',quota_bytes INTEGER,read_only INTEGER DEFAULT 0,allow_upload INTEGER DEFAULT 1,allow_download INTEGER DEFAULT 1,allow_delete INTEGER DEFAULT 1,allow_rename INTEGER DEFAULT 1,allow_move INTEGER DEFAULT 1,allow_copy INTEGER DEFAULT 1,allow_share INTEGER DEFAULT 1,max_upload_bytes INTEGER,allowed_extensions TEXT DEFAULT '[]',blocked_extensions TEXT DEFAULT '[".exe",".bat",".cmd",".ps1",".vbs",".scr",".com"]',show_hidden INTEGER DEFAULT 0,priority INTEGER DEFAULT 100,is_default INTEGER DEFAULT 0,last_seen TEXT,updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS permissions(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,folder_path TEXT DEFAULT '' NOT NULL,rules TEXT NOT NULL,UNIQUE(user_id,drive_id,folder_path));
CREATE TABLE IF NOT EXISTS shares(id INTEGER PRIMARY KEY AUTOINCREMENT,token_hash TEXT UNIQUE NOT NULL,token_hint TEXT NOT NULL,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,relative_path TEXT NOT NULL,owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,mode TEXT NOT NULL,password_hash TEXT,expires_at TEXT,max_downloads INTEGER,download_count INTEGER DEFAULT 0,enabled INTEGER DEFAULT 1,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS favorites(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,relative_path TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(user_id,drive_id,relative_path));
CREATE TABLE IF NOT EXISTS recent_files(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,relative_path TEXT NOT NULL,opened_at TEXT NOT NULL,PRIMARY KEY(user_id,drive_id,relative_path));
CREATE TABLE IF NOT EXISTS trash(id INTEGER PRIMARY KEY AUTOINCREMENT,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,original_path TEXT NOT NULL,trash_path TEXT NOT NULL,item_name TEXT NOT NULL,deleted_by INTEGER REFERENCES users(id) ON DELETE SET NULL,deleted_at TEXT NOT NULL,size_bytes INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS activity_logs(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,username TEXT,action TEXT NOT NULL,target TEXT,drive_id TEXT,ip TEXT,result TEXT NOT NULL,detail TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS file_metadata(drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,relative_path TEXT NOT NULL,name TEXT NOT NULL,extension TEXT,is_dir INTEGER NOT NULL,size_bytes INTEGER NOT NULL,modified_at TEXT NOT NULL,mime_type TEXT,indexed_at TEXT NOT NULL,PRIMARY KEY(drive_id,relative_path));
CREATE INDEX IF NOT EXISTS ix_meta_name ON file_metadata(name COLLATE NOCASE); CREATE INDEX IF NOT EXISTS ix_logs_time ON activity_logs(created_at DESC);
CREATE TABLE IF NOT EXISTS upload_sessions(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,target_path TEXT NOT NULL,temp_path TEXT NOT NULL,expected_size INTEGER NOT NULL,received_size INTEGER DEFAULT 0,conflict_action TEXT NOT NULL DEFAULT 'error',created_at TEXT NOT NULL,expires_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS file_versions(id TEXT PRIMARY KEY,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,relative_path TEXT NOT NULL,stored_name TEXT NOT NULL,size_bytes INTEGER NOT NULL,source_modified_at TEXT,created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,created_at TEXT NOT NULL,reason TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_versions_file ON file_versions(drive_id,relative_path,created_at DESC);
CREATE TABLE IF NOT EXISTS sync_pairs(id TEXT PRIMARY KEY,name TEXT NOT NULL,local_path TEXT NOT NULL,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,cloud_path TEXT NOT NULL,enabled INTEGER DEFAULT 1,interval_seconds INTEGER DEFAULT 60,last_run TEXT,last_result TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sync_state(pair_id TEXT NOT NULL REFERENCES sync_pairs(id) ON DELETE CASCADE,relative_path TEXT NOT NULL,local_size INTEGER,local_mtime REAL,cloud_size INTEGER,cloud_mtime REAL,local_exists INTEGER,cloud_exists INTEGER,PRIMARY KEY(pair_id,relative_path));
CREATE TABLE IF NOT EXISTS file_requests(id TEXT PRIMARY KEY,token TEXT UNIQUE NOT NULL,owner_id INTEGER NOT NULL REFERENCES users(id),drive_id TEXT NOT NULL REFERENCES drives(id),target_path TEXT NOT NULL,title TEXT NOT NULL,instructions TEXT,expires_at TEXT,max_bytes INTEGER,max_uploads INTEGER,password_hash TEXT,allowed_extensions TEXT DEFAULT '[]',enabled INTEGER DEFAULT 1,upload_count INTEGER DEFAULT 0,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS request_uploads(id TEXT PRIMARY KEY,request_id TEXT NOT NULL REFERENCES file_requests(id),target_path TEXT NOT NULL,temp_path TEXT NOT NULL,expected_size INTEGER,received_size INTEGER DEFAULT 0,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tags(id TEXT PRIMARY KEY,owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,name TEXT NOT NULL COLLATE NOCASE,color TEXT NOT NULL DEFAULT '#d7ff45',created_at TEXT NOT NULL,UNIQUE(owner_id,name));
CREATE TABLE IF NOT EXISTS file_tags(user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,tag_id TEXT NOT NULL REFERENCES tags(id) ON DELETE CASCADE,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,relative_path TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(user_id,tag_id,drive_id,relative_path));
CREATE INDEX IF NOT EXISTS ix_file_tags_item ON file_tags(user_id,drive_id,relative_path);
CREATE TABLE IF NOT EXISTS smart_collections(id TEXT PRIMARY KEY,owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,name TEXT NOT NULL,criteria TEXT NOT NULL DEFAULT '{}',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS ocr_index(drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,relative_path TEXT NOT NULL,extracted_text TEXT NOT NULL DEFAULT '',status TEXT NOT NULL,engine TEXT,error TEXT,updated_at TEXT NOT NULL,duration_ms INTEGER DEFAULT 0,PRIMARY KEY(drive_id,relative_path));
CREATE INDEX IF NOT EXISTS ix_ocr_status ON ocr_index(status);
CREATE TABLE IF NOT EXISTS file_hashes(drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,relative_path TEXT NOT NULL,size_bytes INTEGER NOT NULL,modified_at TEXT NOT NULL,sha256 TEXT NOT NULL,updated_at TEXT NOT NULL,PRIMARY KEY(drive_id,relative_path));
CREATE INDEX IF NOT EXISTS ix_hash_sha ON file_hashes(sha256,size_bytes);
CREATE TABLE IF NOT EXISTS automation_rules(id TEXT PRIMARY KEY,owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,name TEXT NOT NULL,trigger_name TEXT NOT NULL,conditions TEXT NOT NULL DEFAULT '{}',actions TEXT NOT NULL DEFAULT '[]',enabled INTEGER NOT NULL DEFAULT 1,dry_run INTEGER NOT NULL DEFAULT 1,last_run TEXT,last_result TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS inbox_items(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,relative_path TEXT NOT NULL,source TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'NEW',created_at TEXT NOT NULL,resolved_at TEXT,UNIQUE(user_id,drive_id,relative_path));
CREATE INDEX IF NOT EXISTS ix_inbox_user_status ON inbox_items(user_id,status,created_at DESC);
CREATE TABLE IF NOT EXISTS notifications(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,kind TEXT NOT NULL,title TEXT NOT NULL,message TEXT,action_url TEXT,is_read INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_notifications_user ON notifications(user_id,is_read,created_at DESC);
CREATE TABLE IF NOT EXISTS storage_samples(id INTEGER PRIMARY KEY AUTOINCREMENT,drive_id TEXT NOT NULL REFERENCES drives(id) ON DELETE CASCADE,total_bytes INTEGER,free_bytes INTEGER,cloud_bytes INTEGER,file_count INTEGER,created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_storage_samples ON storage_samples(drive_id,created_at DESC);
'''
def now_iso():return datetime.now(timezone.utc).isoformat()
def connect():
 con=sqlite3.connect(settings.database_path,timeout=30,check_same_thread=False);con.row_factory=sqlite3.Row;con.execute('PRAGMA foreign_keys=ON');con.execute('PRAGMA busy_timeout=30000');return con
@contextmanager
def connection():
 con=connect()
 try:yield con;con.commit()
 except:con.rollback();raise
 finally:con.close()
def init_db():
 with connection() as con:
  con.executescript(SCHEMA)
  columns={r['name'] for r in con.execute('PRAGMA table_info(upload_sessions)')}
  if 'conflict_action' not in columns:con.execute("ALTER TABLE upload_sessions ADD COLUMN conflict_action TEXT NOT NULL DEFAULT 'error'")
  request_columns={r['name'] for r in con.execute('PRAGMA table_info(file_requests)')}
  for name,definition in [('max_uploads','INTEGER'),('password_hash','TEXT'),('allowed_extensions',"TEXT DEFAULT '[]'")]:
   if name not in request_columns:con.execute(f'ALTER TABLE file_requests ADD COLUMN {name} {definition}')
def one(sql,params=()):
 with connection() as con:return con.execute(sql,tuple(params)).fetchone()
def all(sql,params=()):
 with connection() as con:return con.execute(sql,tuple(params)).fetchall()
def execute(sql,params=()):
 with connection() as con:return con.execute(sql,tuple(params)).lastrowid
def setting_get(key,default=None):
 row=one('SELECT value FROM settings WHERE key=?',(key,))
 if not row:return default
 try:return json.loads(row['value'])
 except:return row['value']
def setting_set(key,value):execute('INSERT INTO settings(key,value,updated_at) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at',(key,json.dumps(value),now_iso()))
def audit(action,target,result,user=None,drive_id=None,ip=None,detail=None):execute('INSERT INTO activity_logs(user_id,username,action,target,drive_id,ip,result,detail,created_at) VALUES(?,?,?,?,?,?,?,?,?)',((user or {}).get('id'),(user or {}).get('username'),action,target,drive_id,ip,result,(detail or '')[:1000],now_iso()))
