from __future__ import annotations

import argparse
import compileall
import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

PRESERVE = {"data", ".env", ".venv", "ngrok.exe"}
VERSION_RE = re.compile(r'__version__\s*=\s*["\']([^"\']+)["\']')


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text("utf-8"))
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return default


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False), "utf-8")
    os.replace(temp, path)


def process_exists(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        if os.name == "nt":
            result = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"], capture_output=True, text=True, timeout=5)
            return f'"{pid}"' in result.stdout
        os.kill(pid, 0)
        return True
    except (OSError, subprocess.SubprocessError):
        return False


def wait_for_exit(pid: int, seconds: int = 60) -> None:
    deadline = time.monotonic() + seconds
    while process_exists(pid) and time.monotonic() < deadline:
        time.sleep(0.25)
    if process_exists(pid):
        raise RuntimeError("The previous server process did not stop in time")


def version_at(root: Path) -> str:
    match = VERSION_RE.search((root / "app" / "__init__.py").read_text("utf-8"))
    if not match:
        raise RuntimeError("The application version could not be verified")
    return match.group(1)


def copy_item(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    if source.is_dir():
        shutil.copytree(source, destination, copy_function=shutil.copy2)
    else:
        shutil.copy2(source, destination)


def remove_item(path: Path) -> None:
    if not path.exists():
        return
    if path.is_dir():
        shutil.rmtree(path)
    else:
        path.unlink()


def managed_items(stage: Path) -> list[str]:
    items = []
    for child in stage.iterdir():
        if child.name.lower() not in PRESERVE and child.name not in {"__pycache__"}:
            items.append(child.name)
    if "app" not in items or "run.py" not in items:
        raise RuntimeError("The staged update is incomplete")
    return sorted(items)


def backup_current(root: Path, backup: Path, names: list[str]) -> None:
    backup.mkdir(parents=True, exist_ok=False)
    for name in names:
        source = root / name
        if source.exists():
            copy_item(source, backup / name)


def apply_stage(root: Path, stage: Path, backup: Path, names: list[str]) -> None:
    applied = []
    try:
        for name in names:
            destination = root / name
            remove_item(destination)
            copy_item(stage / name, destination)
            applied.append(name)
    except Exception:
        for name in reversed(applied):
            remove_item(root / name)
        for name in names:
            saved = backup / name
            if saved.exists():
                remove_item(root / name)
                copy_item(saved, root / name)
        raise


def rollback(root: Path, backup: Path, names: list[str]) -> None:
    for name in names:
        remove_item(root / name)
        saved = backup / name
        if saved.exists():
            copy_item(saved, root / name)


def verify_application(root: Path, expected_version: str) -> None:
    if version_at(root) != expected_version:
        raise RuntimeError("Installed version does not match the staged release")
    if not compileall.compile_dir(str(root / "app"), quiet=1, force=True):
        raise RuntimeError("The updated server failed Python compilation")
    for required in ("run.py", "requirements.txt", "start.bat", "app/static/index.html", "app/static/app.js"):
        if not (root / required).is_file():
            raise RuntimeError(f"Updated installation is missing {required}")


def install_dependencies(root: Path, backup: Path) -> None:
    current = root / "requirements.txt"
    previous = backup / "requirements.txt"
    if previous.exists() and previous.read_bytes() == current.read_bytes():
        return
    result = subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(current)], cwd=root, timeout=900)
    if result.returncode:
        raise RuntimeError("Updated dependencies could not be installed")


def append_history(state_path: Path, item: dict) -> None:
    state = read_json(state_path, {})
    history = list(state.get("history", []))
    history.append(item)
    state["history"] = history[-50:]
    state["last_result"] = item
    if item.get("result") == "SUCCESS":
        state.pop("staged", None)
    write_json(state_path, state)


def prune_backups(backups: Path, keep: int = 3) -> None:
    entries = sorted((item for item in backups.iterdir() if item.is_dir()), key=lambda p: p.stat().st_mtime, reverse=True)
    for item in entries[keep:]:
        shutil.rmtree(item, ignore_errors=True)


def restart(root: Path) -> None:
    time.sleep(3)
    if os.name == "nt":
        os.startfile(str(root / "start.bat"))  # type: ignore[attr-defined]


def main() -> int:
    parser = argparse.ArgumentParser(description="Apply a staged Sol Private Cloud update")
    parser.add_argument("--root", required=True)
    parser.add_argument("--stage", required=True)
    parser.add_argument("--pid", type=int, required=True)
    parser.add_argument("--expected-version", required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    stage = Path(args.stage).resolve()
    data = root / "data"
    state_path = data / "updates" / "state.json"
    log_path = data / "logs" / "update-runner.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    old_version = version_at(root)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = data / "update-backups" / f"{stamp}-v{old_version}"
    names = managed_items(stage)
    result = {"from_version": old_version, "to_version": args.expected_version, "started_at": now(), "result": "FAILED", "message": ""}
    try:
        with log_path.open("a", encoding="utf-8") as log:
            log.write(f"{now()} waiting for server PID {args.pid}\n")
        wait_for_exit(args.pid)
        backup_current(root, backup, names)
        apply_stage(root, stage, backup, names)
        install_dependencies(root, backup)
        verify_application(root, args.expected_version)
        result.update({"result": "SUCCESS", "message": "Update installed and verified", "finished_at": now(), "backup": str(backup)})
        append_history(state_path, result)
        prune_backups(data / "update-backups")
        shutil.rmtree(stage.parent, ignore_errors=True)
        with log_path.open("a", encoding="utf-8") as log:
            log.write(f"{now()} update succeeded: {old_version} -> {args.expected_version}\n")
    except Exception as exc:
        result.update({"message": str(exc)[:500], "finished_at": now(), "backup": str(backup)})
        try:
            if backup.exists():
                rollback(root, backup, names)
                result["message"] += "; previous version restored"
        except Exception as rollback_error:
            result["message"] += "; rollback failed: " + str(rollback_error)[:200]
        append_history(state_path, result)
        with log_path.open("a", encoding="utf-8") as log:
            log.write(f"{now()} update failed: {result['message']}\n")
    finally:
        restart(root)
    return 0 if result["result"] == "SUCCESS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
